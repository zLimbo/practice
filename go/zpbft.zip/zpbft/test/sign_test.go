package test

import (
	"encoding/json"
	"fmt"
	"testing"
	"time"
	"zpbft/pbft"
)

type Message2 struct {
	MsgType   MessageType `json:"msgType"`
	Seq       int64       `json:"seq"`
	NodeId    int64       `json:"nodeId"`
	Timestamp int64       `json:"timestamp"`

	Txs [][256]byte `json:"txs"`
	Req *Message    `json:"req"`
}

func TestSignTime(t *testing.T) {
	fmt.Println("TestSignTime")
	reqMsg := &pbft.Message{
		MsgType:   pbft.MtRequest,
		Seq:       1,
		NodeId:    0,
		Timestamp: time.Now().UnixNano(),

		Txs: new(pbft.BatchTx),
	}
	reqMsgBytes, _ := json.Marshal(reqMsg)
	fmt.Println("reqMsg len:", float64(len(reqMsgBytes))/float64(pbft.MBSize))

	ppMsg := &pbft.Message{
		MsgType: pbft.MtPrePrepare,
		Seq:     1,
		NodeId:  1,

		Timestamp: time.Now().UnixNano(),
		Req:       reqMsg,
	}
	ppMsgBytes, _ := json.Marshal(ppMsg)
	fmt.Println("ppMsg len:", float64(len(ppMsgBytes))/float64(pbft.MBSize))

	priKey, pubKey := pbft.GetKeyPair()

	start := time.Now()
	digest := pbft.Sha256Digest(reqMsg)
	gap1 := time.Since(start)
	start = time.Now()
	sign := pbft.RsaSignWithSha256(digest, priKey)
	gap2 := time.Since(start)
	start = time.Now()
	result := pbft.RsaVerifyWithSha256(digest, sign, pubKey)
	gap3 := time.Since(start)

	fmt.Println("result:", result)
	fmt.Println("digest time:", gap1)
	fmt.Println("sign time:", gap2)
	fmt.Println("verify time:", gap3)
	fmt.Println("sign len:", len(sign))

	t1 := time.Duration(5000)

	fmt.Println("t1:", t1)

}

func TestSignTime2(t *testing.T) {
	fmt.Println("TestSignTime2")
	reqMsg := &pbft.Message{
		MsgType:   pbft.MtRequest,
		Seq:       1,
		NodeId:    0,
		Timestamp: time.Now().UnixNano(),

		Txs: new(pbft.BatchTx),
	}
	reqMsgBytes, _ := json.Marshal(reqMsg)
	fmt.Println("reqMsg size:", float64(len(reqMsgBytes))/float64(pbft.MBSize))

	ppMsg := &pbft.Message{
		MsgType: pbft.MtPrePrepare,
		Seq:     1,
		NodeId:  1,

		Timestamp: time.Now().UnixNano(),
		Req:       reqMsg,
	}
	ppMsgBytes, _ := json.Marshal(ppMsg)
	fmt.Println("ppMsg size:", float64(len(ppMsgBytes))/float64(pbft.MBSize))

	priKey, pubKey := pbft.GetKeyPair()

	start := time.Now()
	signMsg := pbft.SignMsg(ppMsg, priKey)
	signMsgBytes, _ := json.Marshal(signMsg)
	fmt.Println("ppSignMsg size:", float64(len(signMsgBytes))/float64(pbft.MBSize))
	fmt.Println("tx num:", len(signMsg.Msg.Req.Txs))
	fmt.Println("signs num:", len(signMsg.Msg.Req.TxSigns))
	gap1 := time.Since(start)
	start = time.Now()
	result := pbft.VerifySignMsg(signMsg, pubKey)
	gap2 := time.Since(start)

	fmt.Println("result:", result)
	fmt.Println("sign time:", gap1)
	fmt.Println("verify time:", gap2)

	prepare := &pbft.Message{
		MsgType: pbft.MtPrepare,
	}

	prepareSign := pbft.SignMsg(prepare, priKey)

	prepareSignBytes, _ := json.Marshal(prepareSign)
	fmt.Println("len:", len(prepareSignBytes))
}
