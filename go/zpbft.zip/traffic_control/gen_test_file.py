#!/usr/bin/python3
# _*_ coding:utf-8 _*_

import os
import socket

def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    print("# get ip from dial, ip:", ip)
    return ip

if __name__ == '__main__':
    ip = get_host_ip()
    cmd = "dd if=/dev/zero of=" + ip + ".test bs=50M count=20"
    os.system(cmd)
