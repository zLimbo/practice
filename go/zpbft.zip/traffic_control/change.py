#!/usr/bin/python3
# _*_ coding:utf-8 _*_

import os, sys

with open("tc.sh", "r", encoding="utf-8") as f:
    content = f.read()
    idx1 = content.find("dev ") + 4
    idx2 = content.find(" root")
    nic_name = content[idx1:idx2]
    print(nic_name)
    with open("nic_name", "w", encoding="utf-8") as f2:
        f2.write(nic_name)
    content = content.replace("10.11.0.0/16", "10.0.0.0/8")

with open("tc.sh", "w", encoding="utf-8") as f:
    f.write(content)