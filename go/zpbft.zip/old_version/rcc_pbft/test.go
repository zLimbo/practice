package main

import (
	"encoding/json"
	"fmt"
	"rcc_pbft/pbft"
	"time"
)

func main() {

	req := &pbft.RequestMsg{
		Seq:       1,
		NodeId:    1,
		Operator:  "op",
		Timestamp: time.Now().UnixNano(),
		Ext:       make([]byte, 1*pbft.MbSize),
	}

	jsonMsg1, err := json.Marshal(req)
	if err != nil {
		return
	}

	fmt.Println("req size =", float64(len(jsonMsg1))/1024/1024)

	digest, err := pbft.Digest(req)

	prepare := &pbft.PrepareMsg{
		Seq:    5,
		NodeId: 5,
		Digest: digest,
		Ext:    make([]byte, 1200),
	}

	jsonMsg, err := json.Marshal(prepare)
	if err != nil {
		return
	}

	fmt.Println("size =", float64(len(jsonMsg)))

	a := (6 - 1) / 3

	fmt.Println(a)

}
