package main

import (
	"fmt"
	"log"
	"os"
	"strconv"

	"simple_pbft/pbft"
)

func init() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)
}

func main() {
	// 从命令行参数获取结点id
	id, err := strconv.Atoi(os.Args[1])
	if err != nil {
		fmt.Println(err)
		return
	}

	if id == -1 {
		runClient()
	} else {
		runServer(int64(id))
	}
}

func runServer(id int64) {
	server := pbft.NewServer(int64(id))
	if server == nil {
		return
	}
	if len(os.Args) > 2 {
		num, err := strconv.Atoi(os.Args[2])
		sz := 50
		if len(os.Args) > 3 {
			sz1, err := strconv.Atoi(os.Args[3])
			if err == nil {
				sz = sz1
			}
		}
		if err == nil && num > 0 && sz > 0 {
			go server.Node.BoostReq(num, sz)
		}
	}
	server.Start()
}

func runClient() {
	client := pbft.NewClient(pbft.ClientUrl)
	client.Start()
}
