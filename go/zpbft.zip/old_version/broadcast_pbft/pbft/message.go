package pbft

type RequestMsg struct {
	Seq       int64  `json:"seq"`
	NodeId    int64  `json:"nodeId"`
	Operator  string `json:"operator"`
	Timestamp int64  `json:"timestamp"`
	Ext       []byte `json:"ext"`
}

type PrePrepareMsg struct {
	Seq        int64       `json:"seq"`
	NodeId     int64       `json:"nodeId"`
	RequestMsg *RequestMsg `json:"request"`
	Digest     string      `json:"digest"`
	Timestamp  int64       `json:"timestamp"`
	Ext        []byte      `json:"ext"`
}

type PrepareMsg struct {
	Seq       int64  `json:"seq"`
	NodeId    int64  `json:"nodeId"`
	Digest    string `json:"digest"`
	Timestamp int64  `json:"timestamp"`
	Ext       []byte `json:"ext"`
}

type CommitMsg struct {
	Seq       int64  `json:"seq"`
	NodeId    int64  `json:"nodeId"`
	Digest    string `json:"digest"`
	Timestamp int64  `json:"timestamp"`
	Ext       []byte `json:"ext"`
}

type CloudCommitMsg struct {
	Commits   []*CommitMsg `json:"commits"`
	Timestamp int64        `json:"timestamp"`
}

type ReplyMsg struct {
	Seq       int64  `json:"seq"`
	NodeId    int64  `json:"nodeId"`
	Digest    string `json:"digest"`
	Timestamp int64  `json:"timestamp"`
}

type SendStatus int

const (
	NoSend SendStatus = iota
	WaitSend
	HasSend
)

type MsgCert struct {
	Seq    int64
	Digest string

	RequestMsg    *RequestMsg
	PrePrepareMsg *PrePrepareMsg
	Prepares      []*PrepareMsg
	Commits       []*CommitMsg

	SendPrePrepare SendStatus
	SendPrepare    SendStatus
	SendCommit     SendStatus
	SendReply      SendStatus

	RequestTime    int64
	PrePrepareTime int64
	PrepareTime    int64
	CommitTime     int64
	Time           int64
	Time2          int64
}

func NewMsgCert() *MsgCert {
	return &MsgCert{
		Prepares:       make([]*PrepareMsg, 0),
		Commits:        make([]*CommitMsg, 0),
		SendPrePrepare: NoSend,
		SendPrepare:    NoSend,
		SendCommit:     NoSend,
		SendReply:      NoSend,
	}
}

type ReplyCert struct {
	Seq        int64
	CanApply   bool
	Time       int64
	RequestMsg *RequestMsg
	Replys     []*ReplyMsg
}

func NewReplyCert(seq int64) *ReplyCert {
	return &ReplyCert{
		Seq:      seq,
		Replys:   make([]*ReplyMsg, 0),
		CanApply: false,
	}
}

type MsgChan struct {
	RequestMsgChan    chan *RequestMsg
	PrePrepareMsgChan chan *PrePrepareMsg
	PrepareMsgChan    chan *PrepareMsg
	CommitMsgChan     chan *CommitMsg
	ReplyMsgChan      chan *ReplyMsg
}

func NewMsgChan() *MsgChan {
	return &MsgChan{
		RequestMsgChan:    make(chan *RequestMsg, ChanSize),
		PrePrepareMsgChan: make(chan *PrePrepareMsg, ChanSize),
		PrepareMsgChan:    make(chan *PrepareMsg, ChanSize),
		CommitMsgChan:     make(chan *CommitMsg, ChanSize),
		ReplyMsgChan:      make(chan *ReplyMsg, ChanSize),
	}
}
