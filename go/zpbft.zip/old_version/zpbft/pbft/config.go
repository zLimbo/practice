package pbft

import (
	"fmt"
)

const (
	delayTime   = 30 * 100000
	batchNum    = 4
	clientDelay = 3
	ClientUrl   = "10.11.6.119:8000"
	// ClientUrl = "localhost:8800"

	from   = 101
	to     = 102
	MbSize = 1024 * 1024

	ChanSize     = 10000
	sendTaskSize = 256

	ExecTime = 0
)

var (
	f          int
	BoostNum   int
	BoostDelay int = 5
	NodeTable  map[int64]string
	NodeNum    int
	PeerIPs    []string
	PeerIds    []int64
)

func init() {

}

func InitPeers(ipNum, processNum int) error {

	PeerIPs, err := GetPeerIps()
	if err != nil {
		fmt.Println(err)
		return err
	}

	fmt.Println("# PeerIPs:", PeerIPs)

	NodeTable = make(map[int64]string)

	for _, ip := range PeerIPs[:ipNum] {
		idPrefix := Ip2I64(ip)
		for i := 1; i <= processNum; i++ {
			url := ip + ":" + fmt.Sprint(8000+i)
			id := idPrefix*int64(100) + int64(i)
			NodeTable[id] = url
			PeerIds = append(PeerIds, id)
		}
	}

	f = (len(NodeTable) - 1) / 3
	NodeNum = len(NodeTable)

	fmt.Println("# network server peers:")
	for k, v := range NodeTable {
		fmt.Printf("# node id: %d, node url: %s\n", k, v)
	}
	fmt.Println("# client:", ClientUrl)
	fmt.Printf("\n# peer num: %d\tf: %d\n", len(NodeTable), f)

	fmt.Println()

	return nil
}
