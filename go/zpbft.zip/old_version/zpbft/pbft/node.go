package pbft

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net/http"
	"runtime"
	"time"
)

type SendTask struct {
	path      string
	msg       interface{}
	timestamp int64
	msgCert   *MsgCert
}

type Batch struct {
	time1, time2, time3    int64
	count1, count2, count3 int
}

type Node struct {
	id int64
	// msgSendChan chan *SendTask
	msgCert   map[int64]*MsgCert
	latestSeq int64
	times     []int64
	batch     map[int64]*Batch
	batchSeq  int64
	curBatch  *Batch

	RecvChan chan interface{}
	// SendChan *MsgChan
	SendChan chan *SendTask

	sendTaskNoChan chan int
	boostSeqChan   chan int64

	reqNum        int
	prePrepareNum int
	prepareNum    int
	commitNum     int
	replyNum      int

	serverPpNum int
	postErrNum  int

	time3pcSum int64
	count3pc   int64
	time2pcSum int64
	count2pc   int64

	prepareTime int64
	commitTime  int64

	time1 int64
	time2 int64
	time3 int64
	time  int64

	batchTimeOkNum int
}

func NewNode(id int64) *Node {
	node := &Node{
		id: id,
		// msgRecvChan: make(chan interface{}, 10000),
		// msgSendChan: make(chan *SendTask, 10000),
		// RecvChan: NewMsgChan(),
		// SendChan:  NewMsgChan(),
		RecvChan:  make(chan interface{}, ChanSize),
		SendChan:  make(chan *SendTask, ChanSize),
		msgCert:   make(map[int64]*MsgCert),
		latestSeq: -1,

		sendTaskNoChan: make(chan int, sendTaskSize),
		batch:          make(map[int64]*Batch),
		batchSeq:       0,

		times:    make([]int64, 0),
		reqNum:   0,
		replyNum: 0,

		boostSeqChan: make(chan int64, 100),
	}

	for i := 0; i < sendTaskSize; i++ {
		node.sendTaskNoChan <- i
	}
	fmt.Println("** sendTaskNoChan size:", len(node.sendTaskNoChan))

	go node.recv()
	go node.send()

	node.curBatch = &Batch{}
	node.batch[node.batchSeq] = node.curBatch

	return node
}

func (node *Node) recv() {

	for rawMsg := range node.RecvChan {
		fmt.Println("+ handle start + batch seq:", node.batchSeq)

		switch msg := rawMsg.(type) {
		case *RequestMsg:
			node.handleRequestMsg(msg)
		case *PrePrepareMsg:
			node.handlePrePrepareMsg(msg)
		case *PrepareMsg:
			node.handlePrepareMsg(msg)
		case *CommitMsg:
			node.handleCommitMsg(msg)
		}

		fmt.Printf("[req=%d, pre-prepare=%d, prepare=%d, commit=%d, reply=%d]\n",
			node.reqNum,
			node.prePrepareNum,
			node.prepareNum,
			node.commitNum,
			node.replyNum)
		fmt.Println("server receive pre-prepare:", node.serverPpNum)
		fmt.Println("post err num:", node.postErrNum)
		fmt.Println("goroutine num:", runtime.NumGoroutine())

		fmt.Println("+ handle end + batch seq:", node.batchSeq)
	}
}

func (node *Node) getMsgCert(seq int64) *MsgCert {
	msgCert := node.msgCert[seq]
	if msgCert == nil {
		msgCert = NewMsgCert()
		node.msgCert[seq] = msgCert
		msgCert.Seq = seq
	}
	return msgCert
}

func (node *Node) handleRequestMsg(msg *RequestMsg) {
	log.Println("<node handleRequestMsg> msg seq=", msg.Seq, "ext len=", len(msg.Ext))
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.RequestMsg != nil {
		log.Printf("The request(seq=%d) has been accepted!\n", msg.Seq)
		return
	}
	digest, err := Digest(msg)
	if err != nil {
		fmt.Println(err)
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.Digest = digest
	msgCert.RequestMsg = msg
	msgCert.SendPrePrepare = WaitSend

	msgCert.Time = time.Now().UnixNano()
	msgCert.PrePrepareTime = time.Now().UnixNano()
	node.curBatch.time1 = time.Now().UnixNano()
	LogStageStart(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))

	node.sendPrePrepare(msgCert)
}

func (node *Node) handlePrePrepareMsg(msg *PrePrepareMsg) {
	log.Println("<node handlePrePrepareMsg> msg seq=", msg.Seq, "ext len=", len(msg.RequestMsg.Ext))
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.PrePrepareMsg != nil {
		log.Printf("The pre-prepare(seq=%d) has been accepted!\n", msg.Seq)
		return
	}
	if msgCert.SendPrepare == HasSend {
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.Digest = msg.Digest
	msgCert.SendPrepare = WaitSend

	msgCert.Time = time.Now().UnixNano()
	msgCert.PrepareTime = time.Now().UnixNano()
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))

	node.sendPrepare(msgCert)
}

func (node *Node) handlePrepareMsg(msg *PrepareMsg) {
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.SendCommit == HasSend {
		return
	}
	log.Printf("<node handlePrepareMsg> msg seq=%d nodeId=%d\n", msg.Seq, msg.NodeId)
	node.recvPrepareMsg(msgCert, msg)
	node.maybeSendCommit(msgCert)
}

func (node *Node) handleCommitMsg(msg *CommitMsg) {
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.SendReply == HasSend {
		return
	}
	log.Printf("<node handleCommitMsg> msg seq=%d nodeId=%d\n", msg.Seq, msg.NodeId)
	node.recvCommitMsg(msgCert, msg)
	node.maybeSendReply(msgCert)
}

func (node *Node) recvPrepareMsg(msgCert *MsgCert, msg *PrepareMsg) {
	// count := 1
	// for _, preMsg := range msgCert.Prepares {
	// 	if preMsg.NodeId == msg.NodeId {
	// 		return
	// 	}
	// 	if preMsg.Digest == msg.Digest {
	// 		count++
	// 	}
	// }
	msgCert.Prepares = append(msgCert.Prepares, msg)
	count := len(msgCert.Prepares)
	log.Printf("same prepare msg count=%d\n", count)
	if count >= 2*f {
		msgCert.SendCommit = WaitSend
	}
}

func (node *Node) recvCommitMsg(msgCert *MsgCert, msg *CommitMsg) {
	// count := 1
	// for _, preMsg := range msgCert.Commits {
	// 	if preMsg.NodeId == msg.NodeId {
	// 		return
	// 	}
	// 	if preMsg.Digest == msg.Digest {
	// 		count++
	// 	}
	// }
	msgCert.Commits = append(msgCert.Commits, msg)
	count := len(msgCert.Commits)
	log.Printf("same commit msg count=%d\n", count)
	if count >= 2*f+1 {
		msgCert.SendReply = WaitSend
	}
}

func (node *Node) sendPrePrepare(msgCert *MsgCert) {

	timestamp := time.Now().UnixNano()
	prePrepareMsg := &PrePrepareMsg{
		Seq:        msgCert.Seq,
		NodeId:     node.id,
		RequestMsg: msgCert.RequestMsg,
		Digest:     msgCert.Digest,
		Timestamp:  timestamp,
	}
	msgCert.RequestMsg = nil
	node.broadcast(prePrepareMsg, "/getPrePrepare", timestamp, msgCert)
	msgCert.SendPrePrepare = HasSend
	log.Println("[pre-prepare] msg has been sent.")

	node.prePrepareNum++

	msgCert.PrePrepareTime = time.Now().UnixNano() - msgCert.PrePrepareTime
	LogStageEnd(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))

	msgCert.PrepareTime = timestamp
	msgCert.SendPrepare = HasSend
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))
	node.maybeSendCommit(msgCert)
}

func (node *Node) sendPrepare(msgCert *MsgCert) {
	timestamp := time.Now().UnixNano()
	prepareMsg := &PrepareMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: timestamp,
		Ext:       make([]byte, 1200),
	}
	node.recvPrepareMsg(msgCert, prepareMsg)

	log.Println("<broadcast> prepare")
	node.broadcast(prepareMsg, "/getPrepare", timestamp, msgCert)
	msgCert.SendPrepare = HasSend

	node.curBatch.count1++

	if node.curBatch.count1 == BoostNum-1 {
		node.curBatch.time1 = time.Now().UnixNano() - node.curBatch.time1
		node.curBatch.time2 = time.Now().UnixNano()
		fmt.Println("Cal time1:", node.curBatch.time1)
	}
	log.Println("[prepare] msg has been sent.")
	node.maybeSendCommit(msgCert)
}

func (node *Node) maybeSendCommit(msgCert *MsgCert) {
	if msgCert.SendPrepare != HasSend || msgCert.SendCommit != WaitSend {
		return
	}
	node.prepareNum++

	msgCert.PrepareTime = time.Now().UnixNano() - msgCert.PrepareTime
	LogStageEnd(fmt.Sprintf("seq=%d prepare", msgCert.Seq))

	node.curBatch.count2++
	if node.curBatch.count2 == BoostNum {
		node.curBatch.time2 = time.Now().UnixNano() - node.curBatch.time2
		node.curBatch.time3 = time.Now().UnixNano()
		fmt.Println("Cal time2:", node.curBatch.time2)
	}

	msgCert.CommitTime = time.Now().UnixNano()
	LogStageStart(fmt.Sprintf("seq=%d commit", msgCert.Seq))

	commitMsg := &CommitMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: time.Now().UnixNano(),
		Ext:       make([]byte, 1200),
	}

	node.recvCommitMsg(msgCert, commitMsg)
	node.broadcast(commitMsg, "/getCommit", time.Now().UnixNano(), msgCert)
	msgCert.SendCommit = HasSend
	log.Println("[commit] msg has been sent.")
	node.maybeSendReply(msgCert)
}

func (node *Node) maybeSendReply(msgCert *MsgCert) {
	if msgCert.SendCommit != HasSend || msgCert.SendReply != WaitSend {
		return
	}

	msgCert.Time = time.Now().UnixNano() - msgCert.Time
	msgCert.CommitTime = time.Now().UnixNano() - msgCert.CommitTime
	node.commitNum++
	LogStageEnd(fmt.Sprintf("seq=%d commit", msgCert.Seq))

	LogStageStart(fmt.Sprintf("seq=%d reply", msgCert.Seq))
	replyMsg := &ReplyMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: time.Now().UnixNano(),
	}

	node.SendChan <- &SendTask{
		path:    ClientUrl + "/getReply",
		msg:     replyMsg,
		msgCert: msgCert,
	}
	// go PostJson(ClientUrl+"/getReply", jsonMsg)
	msgCert.SendReply = HasSend

	log.Printf("[reply] msg has been sent, seq=%d\n", msgCert.Seq)
	LogStageEnd(fmt.Sprintf("seq=%d reply reply_count=%d", msgCert.Seq, node.replyNum))
	node.replyNum++

	node.finalize(msgCert)
}

func (node *Node) finalize(msgCert *MsgCert) {
	// node.showTime(msgCert)

	node.curBatch.count3++
	if node.curBatch.count3 == BoostNum {
		node.curBatch.time3 = time.Now().UnixNano() - node.curBatch.time3
		fmt.Println("Cal time3:", node.curBatch.time3)

		LogStageEnd(fmt.Sprintf("Batch %d", node.batchSeq))
		node.showBatchTime()
		// node.exec(msgCert)
		node.curBatch = &Batch{}
		node.batchSeq += 1
		node.batch[node.batchSeq] = node.curBatch
		node.boostSeqChan <- node.batchSeq

		LogStageStart(fmt.Sprintf("Batch %d", node.batchSeq))
	}

	node.clearCert(msgCert)
}

func (node *Node) exec(msgCert *MsgCert) {
	LogStageStart("Exec")
	start := time.Now().UnixNano()
	if ExecTime > 0 {
		time.Sleep(time.Microsecond * ExecTime)
	}
	end := time.Now().UnixNano()
	LogStageEnd("Exec")
	fmt.Println("Exec time:", ToSecond(end-start))
}

func (node *Node) clearCert(msgCert *MsgCert) {
	msgCert.RequestMsg = nil
	msgCert.PrePrepareMsg = nil
	msgCert.Prepares = nil
	msgCert.Commits = nil
}

func (node *Node) showBatchTime() {
	fmt.Printf("\033[34m\n[Batch Time seq=%d]\033[0m\n", node.batchSeq)

	fmt.Printf("count1: %d, count2: %d, count3: %d\n", node.curBatch.count1, node.curBatch.count2, node.curBatch.count3)
	fmt.Println("[sum]")
	fmt.Printf("time1: %0.6fs\n", ToSecond(node.curBatch.time1))
	fmt.Printf("time2: %0.6fs\n", ToSecond(node.curBatch.time2))
	fmt.Printf("time3: %0.6fs\n", ToSecond(node.curBatch.time3))
	if ToSecond(node.curBatch.time1) < 10 &&
		ToSecond(node.curBatch.time2) < 10 &&
		ToSecond(node.curBatch.time3) < 10 {
		node.time1 += node.curBatch.time1
		node.time2 += node.curBatch.time2
		node.time3 += node.curBatch.time3
		node.batchTimeOkNum++
	}
	if node.batchTimeOkNum > 0 {
		fmt.Println("\n[avg] batch num:", len(node.batch), "node.batchTimeOkNum:", node.batchTimeOkNum)
		fmt.Printf("time1: %0.6f\n", ToSecond(node.time1/int64(node.batchTimeOkNum)))
		fmt.Printf("time2: %0.6f\n", ToSecond(node.time2/int64(node.batchTimeOkNum)))
		fmt.Printf("time3: %0.6f\n", ToSecond(node.time3/int64(node.batchTimeOkNum)))
	}

	fmt.Println()
}

func (node *Node) showTime(msgCert *MsgCert) {
	fmt.Printf("\033[34m\n[MsgCert Time seq=%d]\033[0m\n", msgCert.Seq)
	// fmt.Printf("request:\t%0.6fs\n", float64(msgCert.RequestTime)/math.Pow10(9))
	// fmt.Printf("pre-prepare:\t%0.6fs\n", float64(msgCert.PrePrepareTime)/math.Pow10(9))
	// fmt.Printf("prepare:\t%0.6fs\n", float64(msgCert.PrepareTime)/math.Pow10(9))
	// fmt.Printf("commit:\t\t%0.6fs\n", float64(msgCert.CommitTime)/math.Pow10(9))
	// fmt.Printf("cert time:\t%0.6fs\n", float64(msgCert.Time)/math.Pow10(9))
	// fmt.Printf("cert time2:\t%0.6fs\n", float64(msgCert.Time2)/math.Pow10(9))

	fmt.Println("\nnode times:")
	for idx, time := range node.times {
		fmt.Printf("%d: %0.6fs\n", idx, float64(time)/math.Pow10(9))
	}
	fmt.Println()

	fmt.Println("")
	if msgCert.Seq/10000 == node.id {
		node.time3pcSum += msgCert.Time
		node.count3pc++
	} else {
		node.time2pcSum += msgCert.Time
		node.count2pc++
		node.prepareTime += msgCert.PrepareTime
		node.commitTime += msgCert.CommitTime
	}

	fmt.Printf("\033[34m\n[Avg Time]\033[0m\n")
	fmt.Println("node time info:")
	fmt.Println("count3pc:", node.count3pc, "count2pc:", node.count2pc)
	fmt.Printf("node.time3pcSum:\t%0.6fs\n", float64(node.time3pcSum)/math.Pow10(9))
	fmt.Printf("node.time2pcSum:\t%0.6fs\n", float64(node.time2pcSum)/math.Pow10(9))
	fmt.Printf("node.prepareTime:\t%0.6fs\n", float64(node.prepareTime)/math.Pow10(9))
	fmt.Printf("node.commitTime:\t%0.6fs\n", float64(node.commitTime)/math.Pow10(9))
	fmt.Printf("node.prepareTime + node.commitTime:\t%0.6fs\n", float64(node.prepareTime+node.commitTime)/math.Pow10(9))

	fmt.Println("Avg time info:")
	if node.count3pc == 0 || node.count2pc == 0 {
		return
	}
	avgTime3pc := float64(node.time3pcSum) / float64(node.count3pc)
	avgTime2pc := float64(node.time2pcSum) / float64(node.count2pc)
	avgTimePrePrepare := avgTime3pc - avgTime2pc
	avgTimePrepare := float64(node.prepareTime) / float64(node.count2pc)
	avgTimeCommit := float64(node.commitTime) / float64(node.count2pc)

	fmt.Printf("avgTime3pc:\t%0.6fs\n", avgTime3pc/math.Pow10(9))
	fmt.Printf("avgTime2pc:\t%0.6fs\n", avgTime2pc/math.Pow10(9))
	fmt.Printf("avgTimePrePrepare:\t%0.6fs\n", avgTimePrePrepare/math.Pow10(9))
	fmt.Printf("avgTimePrepare:\t%0.6fs\n", avgTimePrepare/math.Pow10(9))
	fmt.Printf("avgTimeCommit:\t%0.6fs\n", avgTimeCommit/math.Pow10(9))

}

func (node *Node) broadcast(msg interface{}, path string, timestamp int64, msgCert *MsgCert) {

	for nodeId, url := range NodeTable {
		if nodeId == node.id {
			continue
		}
		// fmt.Println("send to: " + url + path)
		node.SendChan <- &SendTask{
			path:      url + path,
			msg:       msg,
			timestamp: timestamp,
			msgCert:   msgCert,
		}
	}
}

func (node *Node) send() {
	for sendTask := range node.SendChan {

		go node.post(sendTask)
		// node.post(sendTask, sendTaskNo)
	}
}

func (node *Node) post(sendTask *SendTask) {
	jsonMsg, err := json.Marshal(sendTask.msg)
	if err != nil {
		fmt.Println(err)
		return
	}
	buf := bytes.NewBuffer(jsonMsg)

	sendTaskNo := <-node.sendTaskNoChan
	_, err1 := http.Post("http://"+sendTask.path, "application/json", buf)
	node.sendTaskNoChan <- sendTaskNo

	if err1 != nil {
		node.postErrNum++
		fmt.Println("+++++++++++ err num:", node.postErrNum, "\terr:", err1)
		time.Sleep(time.Microsecond * 500)
		node.SendChan <- sendTask
		return
	}

	// calTime(sendTask.msg, sendTask.msgCert)
}

// func calTime(msg interface{}, msgCert *MsgCert) {
// 	switch msg := msg.(type) {
// 	case PrePrepareMsg:
// 		spendTime := time.Now().UnixNano() - msg.Timestamp
// 		msgCert.mutex.Lock()
// 		defer msgCert.mutex.Unlock()
// 		if spendTime > msgCert.PrePrepareTime {
// 			msgCert.PrePrepareTime = spendTime
// 		}
// 	}
// }

func (node *Node) BoostReq(reqNum, reqSize, boostDelay int) {

	req := &RequestMsg{
		Seq:       1,
		NodeId:    1,
		Operator:  "op",
		Timestamp: time.Now().UnixNano(),
		Ext:       make([]byte, reqSize*MbSize),
	}

	jsonMsg, err := json.Marshal(req)
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("# boost num =", reqNum, ", sz =", float64(len(jsonMsg))/MbSize)
	fmt.Println("# boostSeqChan len:", len(node.boostSeqChan))
	time.Sleep(time.Duration(boostDelay) * time.Millisecond)

	node.boostSeqChan <- 0
	LogStageStart(fmt.Sprintf("Batch %d", node.batchSeq))
	prefix := node.id * 10000
	for batchSeq := range node.boostSeqChan {
		if batchSeq == int64(reqNum) {
			break
		}
		fmt.Println("# batchSeq:", batchSeq)
		reqMsg := &RequestMsg{
			Seq:       prefix + batchSeq,
			NodeId:    node.id,
			Operator:  "op",
			Timestamp: time.Now().UnixNano(),
			Ext:       make([]byte, reqSize*MbSize),
		}
		// node.RecvChan.RequestMsgChan <- reqMsg
		node.RecvChan <- reqMsg
	}
}
