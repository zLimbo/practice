package pbft

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

func Digest(object interface{}) (string, error) {
	msg, err := json.Marshal(object)

	if err != nil {
		return "", err
	}

	return Hash(msg), nil
}

func Hash(content []byte) string {
	h := sha256.New()
	h.Write(content)
	return hex.EncodeToString(h.Sum(nil))
}

func PostJson(url string, msg []byte) {
	buf := bytes.NewBuffer(msg)
	_, err := http.Post("http://"+url, "application/json", buf)
	if err != nil {
		fmt.Println("+++++++++++ err!", err)
	}
}

func LogStageStart(msg string) {
	fmt.Printf("\033[031m[%s START] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}

func LogStageEnd(msg string) {
	fmt.Printf("\033[032m[%s END] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}

func GetOutBoundIP() (ip string, err error) {
	file, err := os.OpenFile("local_ip.txt", os.O_RDONLY, 0444)
	if err == nil {
		buf := bufio.NewReader(file)
		line, err := buf.ReadString('\n')
		if err == io.EOF || err == nil {
			ip := strings.TrimSpace(line)
			fmt.Println("** get ip from local_ip.txt, ip:", ip)
			file.Close()
			return ip, nil
		}
	}
	file.Close()
	conn, err := net.Dial("udp", "8.8.8.8:53")
	if err != nil {
		fmt.Println(err)
		return
	}
	localAddr := conn.LocalAddr().(*net.UDPAddr)
	log.Println("localAddr:", localAddr.String())
	ip = strings.Split(localAddr.String(), ":")[0]
	fmt.Println("get ip from dial, ip:", ip)
	return
}

func GetPeerIps() ([]string, error) {
	file, err := os.OpenFile("node.txt", os.O_RDONLY, 0444)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}

	ips := []string{}

	buf := bufio.NewReader(file)
	for {
		line, err := buf.ReadString('\n')
		line = strings.TrimSpace(line)
		ips = append(ips, line)
		if err == io.EOF {
			break
		} else if err != nil {
			fmt.Println(err)
			return nil, err
		}
	}
	return ips, nil
}

func Ip2I64(ip string) int64 {
	res := int64(0)

	for _, span := range strings.Split(ip, ".") {
		num, err := strconv.Atoi(span)
		if err != nil {
			fmt.Println(err)
			return 0
		}
		res = res*1000 + int64(num)
	}
	return res
}

func ToSecond(timestamp int64) float64 {
	return float64(timestamp) / math.Pow10(9)
}
