package pbft

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

type Cloud struct {
	url             string
	cloudCommitMsgs []*CloudCommitMsg
	seqs            map[int64]bool
	commitBuf       map[int64]*CommitMsg
	time            int64
}

func NewCloud(url string) *Cloud {
	cloud := &Cloud{
		url:             url,
		cloudCommitMsgs: make([]*CloudCommitMsg, 0),
		seqs:            make(map[int64]bool),
		commitBuf:       make(map[int64]*CommitMsg),
	}
	cloud.setRoute()

	return cloud
}

func (cloud *Cloud) Start() {
	fmt.Println(cloud.url, "cloud node listen...")
	err := http.ListenAndServe(cloud.url, nil)
	if err != nil {
		fmt.Println(err)
		return
	}
}

func (cloud *Cloud) setRoute() {
	http.HandleFunc("/getCommit", cloud.getCommit)
}

func (cloud *Cloud) getCommit(writer http.ResponseWriter, request *http.Request) {
	var msg CommitMsg
	err := json.NewDecoder(request.Body).Decode(&msg)
	if err != nil {
		fmt.Println(err)
		return
	}
	cloud.handleCommit(&msg)
}

func (cloud *Cloud) handleCommit(msg *CommitMsg) {
	if cloud.seqs[msg.Seq] {
		return
	}
	fmt.Printf("\033[31m[handleCommit]\033[0m msg seq=%d node_id=%d, timestamp=%d\n", msg.Seq, msg.NodeId, time.Now().Unix())

	cloud.commitBuf[msg.Seq] = msg
	cloud.seqs[msg.Seq] = true
	nowTimestamp := time.Now().Unix()
	if len(cloud.commitBuf) >= batchNum {
		cloud.sendBatchCommit()
		cloud.time = nowTimestamp
	}
	// if len(cloud.commitBuf) >= batchNum || nowTimestamp-cloud.time > CloudDelayTime.Microseconds() {
	// 	cloud.sendBatchCommit()
	// 	cloud.time = nowTimestamp
	// }
}

func (cloud *Cloud) sendBatchCommit() {
	fmt.Printf("\033[32m[sendBatchCommit]\033[0m\t")
	cloudCommitMsg := &CloudCommitMsg{
		Commits:   make([]*CommitMsg, 0, len(cloud.commitBuf)),
		Timestamp: time.Now().Unix(),
	}
	for seq, msg := range cloud.commitBuf {
		fmt.Print(seq, " ")
		cloudCommitMsg.Commits = append(cloudCommitMsg.Commits, msg)
	}
	fmt.Println()
	jsonMsg, err := json.Marshal(cloudCommitMsg)
	if err != nil {
		fmt.Println(err)
		return
	}
	for _, url := range NodeTable {
		go PostJson(url+"/getCloudCommit", jsonMsg)
	}
	cloud.commitBuf = make(map[int64]*CommitMsg)
	cloud.cloudCommitMsgs = append(cloud.cloudCommitMsgs, cloudCommitMsg)
}
