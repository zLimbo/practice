package pbft

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"time"
)

type Node struct {
	id          int64
	msgRecvChan chan interface{}
	msgCert     map[int64]*MsgCert
	latestSeq   int64
	times       []int64
}

func NewNode(id int64) *Node {
	node := &Node{
		id:          id,
		msgRecvChan: make(chan interface{}, 100),
		msgCert:     make(map[int64]*MsgCert),
		latestSeq:   -1,
		times:       make([]int64, 0),
	}

	go node.routeMsg()
	return node
}

func (node *Node) routeMsg() {
	for rawMsg := range node.msgRecvChan {
		switch msg := rawMsg.(type) {
		case *RequestMsg:
			node.handleRequestMsg(msg)
		case *PrePrepareMsg:
			node.handlePrePrepareMsg(msg)
		case *PrepareMsg:
			node.handlePrepareMsg(msg)
		// case *CommitMsg:
		// 	node.handleCommitMsg(msg)
		case *CloudCommitMsg:
			node.handleCloudCommitMsg(msg)
		}
	}
}

func (node *Node) getMsgCert(seq int64) *MsgCert {
	msgCert := node.msgCert[seq]
	if msgCert == nil {
		msgCert = NewMsgCert()
		node.msgCert[seq] = msgCert
		msgCert.Seq = seq
		msgCert.Time = time.Now().UnixNano()
		msgCert.Time2 = msgCert.Time
	}
	return msgCert
}

func (node *Node) handleRequestMsg(msg *RequestMsg) {
	log.Println("<node handleRequestMsg> msg seq=", msg.Seq, "ext len=", len(msg.Ext))
	// if msg.Seq <= node.latestSeq {
	// 	log.Printf("The requested seq(=%d) is lower than the latest seq(=%d)\n", msg.Seq, node.latestSeq)
	// 	return
	// }
	if msg.Seq > node.latestSeq {
		node.latestSeq = msg.Seq
	}
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.RequestMsg != nil {
		log.Printf("The request(seq=%d) has been accepted!\n", msg.Seq)
		return
	}
	digest, err := Digest(msg)
	if err != nil {
		fmt.Println(err)
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.Digest = digest
	msgCert.RequestMsg = msg
	msgCert.SendPrePrepare = WaitSend
	LogStageStart(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))

	node.sendPrePrepare(msgCert)
}

func (node *Node) handlePrePrepareMsg(msg *PrePrepareMsg) {
	log.Println("<node handlePrePrepareMsg> msg seq=", msg.Seq, "ext len=", len(msg.RequestMsg.Ext))
	// if msg.NodeId != leaderId {
	// 	log.Println("PrePrepareMsg is not coming from the leader!")
	// 	return
	// }
	if msg.Seq > node.latestSeq {
		node.latestSeq = msg.Seq
	}
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.PrePrepareMsg != nil {
		log.Printf("The pre-prepare(seq=%d) has been accepted!\n", msg.Seq)
		return
	}
	if msgCert.SendPrepare == HasSend {
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.Digest = msg.Digest
	msgCert.RequestMsg = msg.RequestMsg
	msgCert.PrePrepareMsg = msg
	msgCert.RequestTime = msgCert.PrePrepareMsg.Timestamp - msgCert.RequestMsg.Timestamp
	msgCert.PrePrepareTime = time.Now().UnixNano() - msg.Timestamp
	msgCert.PrepareTime = time.Now().UnixNano()
	msgCert.SendPrepare = WaitSend
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))

	node.sendPrepare(msgCert)
}

func (node *Node) handlePrepareMsg(msg *PrepareMsg) {
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.SendCommit == HasSend {
		return
	}
	log.Println("<node handlePrepareMsg> msg:", msg)
	node.recvPrepareMsg(msgCert, msg)
	node.maybeSendCommit(msgCert)
}

// func (node *Node) handleCommitMsg(msg *CommitMsg) {
// 	msgCert := node.getMsgCert(msg.Seq)
// 	if msgCert.SendReply == HasSend {
// 		return
// 	}
// 	log.Println("<node handleCommitMsg> msg:", msg)
// 	node.recvCommitMsg(msgCert, msg)
// 	node.maybeSendReply(msgCert)
// }

func (node *Node) handleCloudCommitMsg(msg *CloudCommitMsg) {
	log.Println("<node handleCloudCommitMsg> msg:", msg)
	for _, commitMsg := range msg.Commits {
		log.Println("<node handleCloudCommitMsg> commitMsg.Seq:", commitMsg.Seq)
		msgCert := node.getMsgCert(commitMsg.Seq)
		if msgCert.SendReply == HasSend {
			return
		}
		// node.recvCommitMsg(msgCert, msg)
		msgCert.SendReply = WaitSend
		node.maybeSendReply(msgCert)
	}
}

func (node *Node) recvPrepareMsg(msgCert *MsgCert, msg *PrepareMsg) {
	count := 1
	for _, preMsg := range msgCert.Prepares {
		if preMsg.NodeId == msg.NodeId {
			return
		}
		if preMsg.Digest == msg.Digest {
			count++
		}
	}
	msgCert.Prepares = append(msgCert.Prepares, msg)
	log.Printf("same prepare msg count=%d\n", count)
	if count >= 2*f {
		msgCert.SendCommit = WaitSend
	}
}

func (node *Node) recvCommitMsg(msgCert *MsgCert, msg *CommitMsg) {
	count := 1
	for _, preMsg := range msgCert.Commits {
		if preMsg.NodeId == msg.NodeId {
			return
		}
		if preMsg.Digest == msg.Digest {
			count++
		}
	}
	msgCert.Commits = append(msgCert.Commits, msg)
	log.Printf("same commit msg count=%d\n", count)
	if count >= 2*f+1 {
		msgCert.SendReply = WaitSend
	}
}

func (node *Node) sendPrePrepare(msgCert *MsgCert) {
	prePrepareMsg := &PrePrepareMsg{
		Seq:        msgCert.Seq,
		NodeId:     node.id,
		RequestMsg: msgCert.RequestMsg,
		Digest:     msgCert.Digest,
		Timestamp:  time.Now().UnixNano(),
	}
	msgCert.PrePrepareMsg = prePrepareMsg
	msgCert.RequestTime = msgCert.PrePrepareMsg.Timestamp - msgCert.RequestMsg.Timestamp
	node.broadcast(prePrepareMsg, "/getPrePrepare")
	msgCert.SendPrePrepare = HasSend
	msgCert.PrePrepareTime = time.Now().UnixNano() - msgCert.PrePrepareMsg.Timestamp
	msgCert.PrepareTime = time.Now().UnixNano()
	log.Println("[pre-prepare] msg has been sent.")
	LogStageEnd(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))
	node.maybeSendCommit(msgCert)
}

func (node *Node) sendPrepare(msgCert *MsgCert) {
	prepareMsg := &PrepareMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: time.Now().UnixNano(),
	}
	node.recvPrepareMsg(msgCert, prepareMsg)

	log.Println("<broadcast> prepare")
	node.broadcast(prepareMsg, "/getPrepare")
	msgCert.SendPrepare = HasSend
	log.Println("[prepare] msg has been sent.")
	node.maybeSendCommit(msgCert)
}

func (node *Node) maybeSendCommit(msgCert *MsgCert) {
	if msgCert.RequestMsg == nil || msgCert.SendCommit != WaitSend {
		return
	}
	msgCert.PrepareTime = time.Now().UnixNano() - msgCert.PrepareTime
	msgCert.CommitTime = time.Now().UnixNano()
	LogStageEnd(fmt.Sprintf("seq=%d prepare", msgCert.Seq))
	LogStageStart(fmt.Sprintf("seq=%d commit", msgCert.Seq))
	commitMsg := &CommitMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: time.Now().UnixNano(),
	}

	node.recvCommitMsg(msgCert, commitMsg)
	// send to cloud
	node.postOne(commitMsg, CloudUrl+"/getCommit")
	// node.broadcast(commitMsg, "/getCommit")
	msgCert.SendCommit = HasSend
	msgCert.Time2 = time.Now().UnixNano() - msgCert.Time2
	if msgCert.RequestMsg.NodeId == node.id {
		node.times = append(node.times, msgCert.Time2)
	}

	log.Println("[commit] msg has been sent.")
	// node.maybeSendReply(msgCert)
}

// func (node *Node) maybeSendCommit(msgCert *MsgCert) {
// 	if msgCert.RequestMsg == nil || msgCert.SendCommit != WaitSend {
// 		return
// 	}
// 	msgCert.PrepareTime = time.Now().UnixNano() - msgCert.PrepareTime
// 	msgCert.CommitTime = time.Now().UnixNano()
// 	LogStageEnd(fmt.Sprintf("seq=%d prepare", msgCert.Seq))
// 	LogStageStart(fmt.Sprintf("seq=%d commit", msgCert.Seq))
// 	commitMsg := &CommitMsg{
// 		Seq:       msgCert.Seq,
// 		NodeId:    node.id,
// 		Digest:    msgCert.Digest,
// 		Timestamp: time.Now().UnixNano(),
// 	}

// 	node.recvCommitMsg(msgCert, commitMsg)
// 	node.broadcast(commitMsg, "/getCommit")
// 	msgCert.SendCommit = HasSend
// 	log.Println("[commit] msg has been sent.")
// 	node.maybeSendReply(msgCert)
// }

func (node *Node) maybeSendReply(msgCert *MsgCert) {
	if msgCert.SendCommit != HasSend || msgCert.SendReply != WaitSend {
		return
	}
	msgCert.CommitTime = time.Now().UnixNano() - msgCert.CommitTime
	LogStageEnd(fmt.Sprintf("seq=%d commit", msgCert.Seq))
	LogStageStart(fmt.Sprintf("seq=%d reply", msgCert.Seq))
	replyMsg := &ReplyMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: time.Now().UnixNano(),
	}
	jsonMsg, err := json.Marshal(replyMsg)
	if err != nil {
		fmt.Println(err)
	}
	PostJson(ClientUrl+"/getReply", jsonMsg)
	msgCert.SendReply = HasSend
	msgCert.Time = time.Now().UnixNano() - msgCert.Time
	log.Printf("[reply] msg has been sent, seq=%d\n", msgCert.Seq)
	LogStageEnd(fmt.Sprintf("seq=%d reply", msgCert.Seq))

	node.showTime(msgCert)

	delete(node.msgCert, msgCert.Seq)
}

func (node *Node) showTime(msgCert *MsgCert) {
	fmt.Printf("\033[34m\n[MsgCert Time seq=%d]\033[0m\n", msgCert.Seq)
	fmt.Printf("request:\t%0.6fs\n", float64(msgCert.RequestTime)/math.Pow10(9))
	fmt.Printf("pre-prepare:\t%0.6fs\n", float64(msgCert.PrePrepareTime)/math.Pow10(9))
	fmt.Printf("prepare:\t%0.6fs\n", float64(msgCert.PrepareTime)/math.Pow10(9))
	fmt.Printf("commit:\t\t%0.6fs\n", float64(msgCert.CommitTime)/math.Pow10(9))
	fmt.Printf("cert time:\t%0.6fs\n", float64(msgCert.Time)/math.Pow10(9))
	fmt.Printf("cert time2:\t%0.6fs\n", float64(msgCert.Time2)/math.Pow10(9))

	fmt.Println("\nnode times:")
	for idx, time := range node.times {
		fmt.Printf("%d: %0.6fs\n", idx, float64(time)/math.Pow10(9))
	}
	fmt.Println()
}

func (node *Node) broadcast(msg interface{}, path string) map[int64]error {
	errorMap := make(map[int64]error)

	for nodeId, url := range NodeTable {
		if nodeId == node.id {
			continue
		}
		jsonMsg, err := json.Marshal(msg)
		if err != nil {
			errorMap[nodeId] = err
			continue
		}
		go PostJson(url+path, jsonMsg)
	}
	if len(errorMap) == 0 {
		return nil
	} else {
		return errorMap
	}
}

func (node *Node) postOne(msg interface{}, url string) {
	jsonMsg, err := json.Marshal(msg)
	if err != nil {
		fmt.Println(err)
		return
	}
	go PostJson(url, jsonMsg)
}
