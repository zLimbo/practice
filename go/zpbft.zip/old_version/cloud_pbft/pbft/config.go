package pbft

import (
	"fmt"
	"time"
)

const (
	f              = 1
	delayTime      = 30 * 100000
	CloudDelayTime = time.Second * 20
	batchNum       = 4
	// clientUrl = "10.11.7.75:8800"
	// cloudUrl  = "10.11.7.76:8801"
	ClientUrl = "localhost:8800"
	CloudUrl  = "localhost:8801"

	from   = 101
	to     = 102
	MbSize = 1024 * 1024
)

var NodeTable map[int64]string

func init() {
	NodeTable = make(map[int64]string)
	// NodeTable[1] = "10.11.7.71:8880"
	// NodeTable[2] = "10.11.7.72:8880"
	// NodeTable[3] = "10.11.7.73:8880"
	// NodeTable[4] = "10.11.7.74:8880"
	NodeTable[1] = "localhost:8881"
	NodeTable[2] = "localhost:8882"
	NodeTable[3] = "localhost:8883"
	NodeTable[4] = "localhost:8884"

	fmt.Println("network server peers:")
	for k, v := range NodeTable {
		fmt.Printf("node id: %d, node url: %s\n", k, v)
	}
	fmt.Println("client:", ClientUrl)
	fmt.Println("cloud:", CloudUrl)

	fmt.Println()
}
