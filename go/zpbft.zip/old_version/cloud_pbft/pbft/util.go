package pbft

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

func Digest(object interface{}) (string, error) {
	msg, err := json.Marshal(object)

	if err != nil {
		return "", err
	}

	return Hash(msg), nil
}

func Hash(content []byte) string {
	h := sha256.New()
	h.Write(content)
	return hex.EncodeToString(h.Sum(nil))
}

func PostJson(url string, msg []byte) {
	buf := bytes.NewBuffer(msg)
	http.Post("http://"+url, "application/json", buf)
}

func LogStageStart(msg string) {
	fmt.Printf("\033[031m[%s START] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}

func LogStageEnd(msg string) {
	fmt.Printf("\033[032m[%s END] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}
