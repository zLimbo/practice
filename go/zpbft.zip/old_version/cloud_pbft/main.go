package main

import (
	"fmt"
	"log"
	"os"
	"strconv"

	"simple_pbft/pbft"
)

func init() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)
}

func main() {
	// 从命令行参数获取结点id
	id, err := strconv.Atoi(os.Args[1])
	if err != nil {
		fmt.Println(err)
		return
	}

	if id == -1 {
		runClient()
	} else if id == -2 {
		runCloud()
	} else {
		runServer(int64(id))
	}
}

func runServer(id int64) {
	server := pbft.NewServer(int64(id))
	if server == nil {
		return
	}
	server.Start()
}

func runClient() {
	client := pbft.NewClient(pbft.ClientUrl)
	client.Start()
}

func runCloud() {
	cloud := pbft.NewCloud(pbft.CloudUrl)
	cloud.Start()
}
