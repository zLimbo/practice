package pbft

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"runtime"
	"time"
)

type SendTask struct {
	path string
	msg  []byte
}

type Node struct {
	id          int64
	msgRecvChan chan interface{}
	msgSendChan chan *SendTask
	msgCert     map[int64]*MsgCert
	latestSeq   int64
	times       []int64

	reqNum        int
	prePrepareNum int
	prepareNum    int
	commitNum     int
	replyNum      int

	serverPpNum int
	postErrNum  int
}

func NewNode(id int64) *Node {
	node := &Node{
		id:          id,
		msgRecvChan: make(chan interface{}, 10000),
		msgSendChan: make(chan *SendTask, 10000),
		msgCert:     make(map[int64]*MsgCert),
		latestSeq:   -1,
		times:       make([]int64, 0),
		reqNum:      0,
		replyNum:    0,
	}

	go node.recv()
	go node.send()
	return node
}

func (node *Node) recv() {
	for rawMsg := range node.msgRecvChan {
		fmt.Println("+ route start + chan_len =", len(node.msgRecvChan))
		switch msg := rawMsg.(type) {
		case *RequestMsg:
			node.handleRequestMsg(msg)
		case *PrePrepareMsg:
			node.handlePrePrepareMsg(msg)
		case *PrepareMsg:
			node.handlePrepareMsg(msg)
		case *CommitMsg:
			node.handleCommitMsg(msg)
		}
		fmt.Println("+ route end + chan_len =", len(node.msgRecvChan))
		fmt.Printf("[req=%d, pre-prepare=%d, prepare=%d, commit=%d, reply=%d]\n",
			node.reqNum,
			node.prePrepareNum,
			node.prepareNum,
			node.commitNum,
			node.replyNum)
		fmt.Println("server receive pre-prepare:", node.serverPpNum)
		fmt.Println("goroutine num:", runtime.NumGoroutine())
	}
}

func (node *Node) post(sendTask *SendTask) {
	buf := bytes.NewBuffer(sendTask.msg)
	_, err := client.Post("http://"+sendTask.path, "application/json", buf)
	if err != nil {
		node.postErrNum++
		fmt.Println("+++++++++++ err num:", node.postErrNum, "\terr:", err)
		time.Sleep(time.Second * 5)
		node.msgSendChan <- sendTask
	}
}

func (node *Node) send() {
	for sendTask := range node.msgSendChan {
		go node.post(sendTask)
	}
}

func (node *Node) getMsgCert(seq int64) *MsgCert {
	msgCert := node.msgCert[seq]
	if msgCert == nil {
		msgCert = NewMsgCert()
		node.msgCert[seq] = msgCert
		msgCert.Seq = seq
		msgCert.Time = time.Now().UnixNano()
		msgCert.Time2 = msgCert.Time
	}
	return msgCert
}

func (node *Node) handleRequestMsg(msg *RequestMsg) {
	log.Println("<node handleRequestMsg> msg seq=", msg.Seq, "ext len=", len(msg.Ext))
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.RequestMsg != nil {
		log.Printf("The request(seq=%d) has been accepted!\n", msg.Seq)
		return
	}
	digest, err := Digest(msg)
	if err != nil {
		fmt.Println(err)
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.Digest = digest
	msgCert.RequestMsg = msg
	msgCert.SendPrePrepare = WaitSend
	LogStageStart(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))

	node.sendPrePrepare(msgCert)
}

func (node *Node) handlePrePrepareMsg(msg *PrePrepareMsg) {
	log.Println("<node handlePrePrepareMsg> msg seq=", msg.Seq, "ext len=", len(msg.RequestMsg.Ext))
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.PrePrepareMsg != nil {
		log.Printf("The pre-prepare(seq=%d) has been accepted!\n", msg.Seq)
		return
	}
	if msgCert.SendPrepare == HasSend {
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.Digest = msg.Digest
	// msgCert.RequestMsg = msg.RequestMsg
	// msgCert.PrePrepareMsg = msg
	// msgCert.RequestTime = msgCert.PrePrepareMsg.Timestamp - msgCert.RequestMsg.Timestamp
	msgCert.PrePrepareTime = time.Now().UnixNano() - msg.Timestamp
	msgCert.PrepareTime = time.Now().UnixNano()
	msgCert.SendPrepare = WaitSend
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))

	node.sendPrepare(msgCert)
}

func (node *Node) handlePrepareMsg(msg *PrepareMsg) {
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.SendCommit == HasSend {
		return
	}
	log.Printf("<node handlePrepareMsg> msg seq=%d nodeId=%d\n", msg.Seq, msg.NodeId)
	node.recvPrepareMsg(msgCert, msg)
	node.maybeSendReply(msgCert)
}

func (node *Node) handleCommitMsg(msg *CommitMsg) {
	msgCert := node.getMsgCert(msg.Seq)
	if msgCert.SendReply == HasSend {
		return
	}
	log.Printf("<node handleCommitMsg> msg seq=%d nodeId=%d\n", msg.Seq, msg.NodeId)
	node.recvCommitMsg(msgCert, msg)
	node.maybeSendReply(msgCert)
}

func (node *Node) recvPrepareMsg(msgCert *MsgCert, msg *PrepareMsg) {
	// count := 1
	// for _, preMsg := range msgCert.Prepares {
	// 	if preMsg.NodeId == msg.NodeId {
	// 		return
	// 	}
	// 	if preMsg.Digest == msg.Digest {
	// 		count++
	// 	}
	// }
	msgCert.Prepares = append(msgCert.Prepares, msg)
	count := len(msgCert.Prepares)
	log.Printf("same prepare msg count=%d\n", count)
	if count >= 2*f {
		// msgCert.SendCommit = WaitSend
		msgCert.SendReply = WaitSend
	}
}

func (node *Node) recvCommitMsg(msgCert *MsgCert, msg *CommitMsg) {
	// count := 1
	// for _, preMsg := range msgCert.Commits {
	// 	if preMsg.NodeId == msg.NodeId {
	// 		return
	// 	}
	// 	if preMsg.Digest == msg.Digest {
	// 		count++
	// 	}
	// }
	msgCert.Commits = append(msgCert.Commits, msg)
	count := len(msgCert.Commits)
	log.Printf("same commit msg count=%d\n", count)
	if count >= 2*f+1 {
		msgCert.SendReply = WaitSend
	}
}

func (node *Node) sendPrePrepare(msgCert *MsgCert) {
	prePrepareMsg := &PrePrepareMsg{
		Seq:        msgCert.Seq,
		NodeId:     node.id,
		RequestMsg: msgCert.RequestMsg,
		Digest:     msgCert.Digest,
		Timestamp:  time.Now().UnixNano(),
	}
	msgCert.RequestMsg = nil
	// msgCert.PrePrepareMsg = prePrepareMsg
	// msgCert.RequestTime = msgCert.PrePrepareMsg.Timestamp - msgCert.RequestMsg.Timestamp
	node.broadcast(prePrepareMsg, "/getPrePrepare")
	msgCert.SendPrePrepare = HasSend
	// msgCert.PrePrepareTime = time.Now().UnixNano() - msgCert.PrePrepareMsg.Timestamp
	msgCert.PrepareTime = time.Now().UnixNano()
	log.Println("[pre-prepare] msg has been sent.")
	LogStageEnd(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))
	node.prePrepareNum++
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))
	node.maybeSendReply(msgCert)
}

func (node *Node) sendPrepare(msgCert *MsgCert) {
	prepareMsg := &PrepareMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: time.Now().UnixNano(),
		Ext:       make([]byte, 1200),
	}
	node.recvPrepareMsg(msgCert, prepareMsg)

	log.Println("<broadcast> prepare")
	node.broadcast(prepareMsg, "/getPrepare")
	msgCert.SendPrepare = HasSend
	log.Println("[prepare] msg has been sent.")
	node.maybeSendReply(msgCert)
}

// func (node *Node) maybeSendCommit(msgCert *MsgCert) {
// 	if msgCert.SendCommit != WaitSend {
// 		return
// 	}
// 	msgCert.PrepareTime = time.Now().UnixNano() - msgCert.PrepareTime
// 	msgCert.CommitTime = time.Now().UnixNano()
// 	LogStageEnd(fmt.Sprintf("seq=%d prepare", msgCert.Seq))
// 	node.prepareNum++
// 	LogStageStart(fmt.Sprintf("seq=%d commit", msgCert.Seq))
// 	commitMsg := &CommitMsg{
// 		Seq:       msgCert.Seq,
// 		NodeId:    node.id,
// 		Digest:    msgCert.Digest,
// 		Timestamp: time.Now().UnixNano(),
// 		Ext:       make([]byte, 1200),
// 	}

// 	node.recvCommitMsg(msgCert, commitMsg)
// 	node.broadcast(commitMsg, "/getCommit")
// 	msgCert.SendCommit = HasSend
// 	log.Println("[commit] msg has been sent.")
// 	node.maybeSendReply(msgCert)
// }

func (node *Node) maybeSendReply(msgCert *MsgCert) {
	if msgCert.SendReply != WaitSend {
		return
	}
	msgCert.CommitTime = time.Now().UnixNano() - msgCert.CommitTime
	LogStageEnd(fmt.Sprintf("seq=%d commit", msgCert.Seq))
	node.commitNum++
	LogStageStart(fmt.Sprintf("seq=%d reply", msgCert.Seq))
	replyMsg := &ReplyMsg{
		Seq:       msgCert.Seq,
		NodeId:    node.id,
		Digest:    msgCert.Digest,
		Timestamp: time.Now().UnixNano(),
	}
	jsonMsg, err := json.Marshal(replyMsg)
	if err != nil {
		fmt.Println(err)
	}

	node.msgSendChan <- &SendTask{
		path: ClientUrl + "/getReply",
		msg:  jsonMsg,
	}
	// go PostJson(ClientUrl+"/getReply", jsonMsg)
	msgCert.SendReply = HasSend

	msgCert.Time = time.Now().UnixNano() - msgCert.Time
	log.Printf("[reply] msg has been sent, seq=%d\n", msgCert.Seq)
	LogStageEnd(fmt.Sprintf("seq=%d reply reply_count=%d", msgCert.Seq, node.replyNum))
	node.replyNum++

	// node.showTime(msgCert)

	node.clearCert(msgCert)
}

func (node *Node) clearCert(msgCert *MsgCert) {
	msgCert.RequestMsg = nil
	msgCert.PrePrepareMsg = nil
	msgCert.Prepares = nil
	msgCert.Commits = nil
}

// func (node *Node) showTime(msgCert *MsgCert) {
// 	fmt.Printf("\033[34m\n[MsgCert Time seq=%d]\033[0m\n", msgCert.Seq)
// 	fmt.Printf("request:\t%0.6fs\n", float64(msgCert.RequestTime)/math.Pow10(9))
// 	fmt.Printf("pre-prepare:\t%0.6fs\n", float64(msgCert.PrePrepareTime)/math.Pow10(9))
// 	fmt.Printf("prepare:\t%0.6fs\n", float64(msgCert.PrepareTime)/math.Pow10(9))
// 	fmt.Printf("commit:\t\t%0.6fs\n", float64(msgCert.CommitTime)/math.Pow10(9))
// 	fmt.Printf("cert time:\t%0.6fs\n", float64(msgCert.Time)/math.Pow10(9))
// 	fmt.Printf("cert time2:\t%0.6fs\n", float64(msgCert.Time2)/math.Pow10(9))

// 	fmt.Println("\nnode times:")
// 	for idx, time := range node.times {
// 		fmt.Printf("%d: %0.6fs\n", idx, float64(time)/math.Pow10(9))
// 	}
// 	fmt.Println()
// }

func (node *Node) broadcast(msg interface{}, path string) map[int64]error {
	errorMap := make(map[int64]error)

	for nodeId, url := range NodeTable {
		if nodeId == node.id {
			continue
		}
		jsonMsg, err := json.Marshal(msg)
		if err != nil {
			errorMap[nodeId] = err
			continue
		}
		// fmt.Println("send to: " + url + path)
		node.msgSendChan <- &SendTask{
			path: url + path,
			msg:  jsonMsg,
		}
	}
	if len(errorMap) == 0 {
		return nil
	} else {
		return errorMap
	}
}

func (node *Node) BoostReq(num int, sz int) {
	pre := node.id * 100000

	req := &RequestMsg{
		Seq:       1,
		NodeId:    1,
		Operator:  "op",
		Timestamp: time.Now().UnixNano(),
		Ext:       make([]byte, sz*MbSize),
	}
	jsonMsg, err := json.Marshal(req)
	if err != nil {
		return
	}

	fmt.Println("boost num =", num, ", sz =", float64(len(jsonMsg))/MbSize)
	time.Sleep(time.Second * boost_delay)
	for i := 0; i < num; i++ {
		// time.Sleep(time.Mi)
		msg := &RequestMsg{
			Seq:       pre + int64(i),
			NodeId:    node.id,
			Operator:  "op",
			Timestamp: time.Now().UnixNano(),
			Ext:       make([]byte, sz*MbSize),
		}

		node.msgRecvChan <- msg
	}
}
