package pbft

import (
	"fmt"
)

const (
	delayTime = 30 * 100000
	batchNum  = 4
	ClientUrl = "10.11.7.75:8000"
	// ClientUrl = "localhost:8800"

	from        = 101
	to          = 102
	MbSize      = 1024 * 1024
	boost_delay = 5
)

var f int = 1

var NodeTable map[int64]string

var PeerIPs = []string{
	"10.11.7.71",
	"10.11.7.72",
	"10.11.7.73",
	"10.11.7.74",
}

func InitPeers(num int) {

	f = (num*4 - 1) / 3

	NodeTable = make(map[int64]string)

	for idx, ip := range PeerIPs {

		for i := 1; i <= num; i++ {
			url := ip + ":" + fmt.Sprint(8000+i)
			id := (71+idx)*10000 + 8000 + i
			NodeTable[int64(id)] = url
		}
	}

	fmt.Println("network server peers:")
	for k, v := range NodeTable {
		fmt.Printf("node id: %d, node url: %s\n", k, v)
	}
	fmt.Println("client:", ClientUrl)
	fmt.Printf("\npeer num: %d\tf: %d\n", len(NodeTable), f)

	fmt.Println()
}
