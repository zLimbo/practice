package pbft

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net/http"
	"sort"
	"sync"
	"time"
)

type Client struct {
	url          string
	replyCert    map[int64]*ReplyCert
	replyChan    chan *ReplyMsg
	applySeqChan chan int64
	time         int64
	mutex        sync.Mutex
}

func NewClient(url string) *Client {
	client := &Client{
		url:          url,
		replyCert:    make(map[int64]*ReplyCert),
		replyChan:    make(chan *ReplyMsg, 100),
		applySeqChan: make(chan int64, 100),
	}
	client.setRoute()

	// go client.testPostCloud()
	// go client.handleReply()
	go client.routeMsg()
	go client.apply()

	return client
}

func (client *Client) Start() {
	client.time = time.Now().UnixNano() + int64(boost_delay*math.Pow10(9))
	fmt.Println(client.url, " client node listen...")
	err := http.ListenAndServe(client.url, nil)
	if err != nil {
		fmt.Println(err)
		return
	}
}

func (client *Client) setRoute() {
	http.HandleFunc("/getReply", client.getReply)
}

func (client *Client) getReply(writer http.ResponseWriter, request *http.Request) {
	var msg ReplyMsg
	err := json.NewDecoder(request.Body).Decode(&msg)
	if err != nil {
		fmt.Println(err)
		return
	}
	client.replyChan <- &msg
	// client.handleReply(&msg)
}

func (client *Client) routeMsg() {
	for msg := range client.replyChan {
		client.handleReply(msg)
	}
}

func (client *Client) handleReply(msg *ReplyMsg) {
	cert, ok := client.replyCert[msg.Seq]
	if !ok {
		cert = NewReplyCert(msg.Seq)
		client.replyCert[msg.Seq] = cert
	}
	if cert.CanApply {
		return
	}
	count := 1
	for _, preMsg := range cert.Replys {
		if preMsg.NodeId == msg.NodeId {
			return
		}
		if preMsg.Digest == msg.Digest {
			count++
		}
	}
	cert.Replys = append(cert.Replys, msg)
	fmt.Printf("\033[32m[Reply]\033[0m msg seq=%d node_id=%d, count=%d\n", msg.Seq, msg.NodeId, count)
	if count >= f+1 {
		client.mutex.Lock()
		if cert.CanApply {
			return
		}
		client.replyCert[msg.Seq].CanApply = true
		client.mutex.Unlock()
		client.applySeqChan <- msg.Seq
	}
}

func (client *Client) apply() {
	seqs := make([]int, 0)
	for seq := range client.applySeqChan {
		// cert := client.replyCert[seq]
		// fmt.Printf("\033[33m[Apply]\033[0m seq=%d can apply, spend time=%0.6f\n", seq, float64(cert.Time)/math.Pow10(9))
		seqs = append(seqs, int(seq))
		sort.Ints(seqs)
		// fmt.Println("apply seqs:", seqs)
		fmt.Printf("[time] num=%d\tspend time=%0.6f\n", len(seqs), float64(time.Now().UnixNano()-client.time)/math.Pow10(9))
	}
}

func (client *Client) testPostCloud() {
	log.Println("testPostCloud")
	var pre int64 = 1000000000
	sz := 50

	client.time = time.Now().UnixNano()
	for i := 0; i < 50; i++ {
		nodeId := int64(i%4 + 1)
		// nodeId := int64(1)
		msg := &RequestMsg{
			Seq:       pre + int64(i),
			NodeId:    nodeId,
			Operator:  "op",
			Timestamp: time.Now().UnixNano(),
			Ext:       make([]byte, sz*MbSize),
		}
		jsonMsg, err := json.Marshal(msg)
		if err != nil {
			fmt.Println(err)
			return
		}
		fmt.Printf("\033[31m[Req]\033[0m msg seq=%d ext_len=%d, timestamp=%d\n", msg.Seq, len(msg.Ext), time.Now().Unix())

		cert := NewReplyCert(msg.Seq)
		client.replyCert[msg.Seq] = cert
		cert.RequestMsg = msg

		url := NodeTable[int64(nodeId)]
		PostJson(url+"/getRequest", jsonMsg)
	}

}
