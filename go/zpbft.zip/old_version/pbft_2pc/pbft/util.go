package pbft

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"strings"
	"time"
)

func Digest(object interface{}) (string, error) {
	msg, err := json.Marshal(object)

	if err != nil {
		return "", err
	}

	return Hash(msg), nil
}

func Hash(content []byte) string {
	h := sha256.New()
	h.Write(content)
	return hex.EncodeToString(h.Sum(nil))
}

var client = &http.Client{
	Transport: &http.Transport{
		MaxIdleConns: 32,
	},
}

func PostJson(url string, msg []byte) {
	buf := bytes.NewBuffer(msg)
	_, err := client.Post("http://"+url, "application/json", buf)
	if err != nil {
		fmt.Println("+++++++++++ err!", err)
	}
}

func LogStageStart(msg string) {
	fmt.Printf("\033[031m[%s START] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}

func LogStageEnd(msg string) {
	fmt.Printf("\033[032m[%s END] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}

func GetOutBoundIP() (ip string, err error) {
	conn, err := net.Dial("udp", "8.8.8.8:53")
	if err != nil {
		fmt.Println(err)
		return
	}
	localAddr := conn.LocalAddr().(*net.UDPAddr)
	fmt.Println(localAddr.String())
	ip = strings.Split(localAddr.String(), ":")[0]
	return
}
