git pull
rm ./zpbft
go build