package test

import (
	"fmt"
	"testing"
	"zpbft/pbft"
)

func TestLocalIP(t *testing.T) {
	ip := pbft.GetOutBoundIP()
	fmt.Println("local ip:", ip)
}
