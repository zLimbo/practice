package test

import (
	"fmt"
	"testing"
	"time"
)

func TestExecTime(t *testing.T) {
	start := time.Now()
	sum := int64(0)
	num := int64(1e10)
	for i := int64(0); i < num; i++ {
		sum += 1
	}
	fmt.Println("Exec result:", sum)
	fmt.Println("Exec time:", time.Since(start))
}