package test

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"testing"
	"time"
	"zpbft/pbft"
)

var priKey, pubKey = pbft.ReadKeyPair("../certs/1001100119301")

func client(addr string) {

	conn, err := net.Dial("tcp", addr)
	if err != nil {
		log.Panic(err)
	}
	for i := 0; i < 10; i++ {
		reqMsg := &pbft.Message{
			MsgType:   pbft.MtRequest,
			Seq:       1,
			NodeId:    0,
			Timestamp: time.Now().UnixNano(),
			Txs:       new(pbft.BatchTx),
		}
		reqMsgBytes, _ := json.Marshal(reqMsg)
		fmt.Println("reqMsg size:", float64(len(reqMsgBytes))/float64(pbft.MbSize))

		ppMsg := &pbft.Message{
			MsgType: pbft.MtPrePrepare,
			Seq:     int64(i),
			NodeId:  1,

			Timestamp: time.Now().UnixNano(),
			Req:       reqMsg,
		}
		ppMsgBytes, _ := json.Marshal(ppMsg)
		fmt.Println("ppMsg size:", float64(len(ppMsgBytes))/float64(pbft.MbSize))

		signMsg := pbft.GetSignMsg(ppMsg, priKey)
		signMsgBytes, _ := json.Marshal(signMsg)
		result := pbft.VerifySignMsg(signMsg, pubKey)
		fmt.Println("result:", result)
		fmt.Println("signMsg byte size:", len(signMsgBytes))

		sz := len(signMsgBytes)
		szBytes := pbft.I2Bytes(sz, 4)
		start := time.Now()
		data := append(szBytes, signMsgBytes...)
		fmt.Println("append spend:", time.Since(start))

		n, err := conn.Write(data)
		if err != nil {
			fmt.Println("err:", err)
		}
		fmt.Println("n:", n)
	}
	conn.Close()
}

type ConnMgr struct {
	conn    *net.Conn
	status  int
	msgLen  int
	pos     int
	buf     []byte
	bufChan chan []byte
}

var Mgr = &ConnMgr{
	conn:    nil,
	status:  0,
	msgLen:  0,
	pos:     0,
	buf:     make([]byte, 0),
	bufChan: make(chan []byte),
}

func recvMsg() {

	for buf := range Mgr.bufChan {
		Mgr.buf = append(Mgr.buf, buf...)

		for {
			if len(Mgr.buf) < 4 {
				break
			}
			size := pbft.Bytes2I(Mgr.buf[:4], 4)
			if len(Mgr.buf) < 4+size {
				break
			}
			signMsg := new(pbft.SignMessage)
			err := json.Unmarshal(Mgr.buf[4:4+size], signMsg)
			if err != nil {
				log.Panic(err)
			}
			fmt.Println("signMsg:", signMsg.Msg.Seq)
			result := pbft.VerifySignMsg(signMsg, pubKey)
			fmt.Println("result:", result)
			Mgr.buf = Mgr.buf[4+size:]
		}
	}
}

func server(addr string) {
	fmt.Println(addr, "listen...")
	listen, err := net.Listen("tcp", addr)
	if err != nil {
		log.Panic(err)
	}
	defer listen.Close()

	conn, err := listen.Accept()
	if err != nil {
		log.Panic(err)
	}

	Mgr.conn = &conn

	go recvMsg()

	for {
		buf := make([]byte, 1e8)
		n, err := conn.Read(buf)
		if err != nil {
			fmt.Println(err)
		}
		fmt.Println("n:", n)
		if n == 0 {
			break
		}

		Mgr.bufChan <- buf[:n]
	}

	conn.Close()
}

func TestLongTermConn(t *testing.T) {
	fmt.Println(os.Args[4])
	name := os.Args[4]
	ip := os.Args[5]
	// ip := pbft.GetOutBoundIP()
	addr := ip + ":8020"
	if name == "server" {
		server(addr)
	} else if name == "client" {
		client(addr)
	} else {
		fmt.Println("parameter error!")
	}
}
