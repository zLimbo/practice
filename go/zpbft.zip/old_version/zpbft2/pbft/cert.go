package pbft

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"strconv"
	"time"
)

//如果当前目录下不存在目录Keys，则创建目录，并为各个节点生成rsa公私钥
func GenRsaKeys(nodeNum int) {
	if !IsExist("./certs") {
		fmt.Println("检测到还未生成公私钥目录，正在生成公私钥 ...")
		err := os.Mkdir("certs", 0644)
		if err != nil {
			log.Panic(err)
		}
		for i := 1; i <= nodeNum; i++ {
			if !IsExist("./certs/node" + strconv.Itoa(i)) {
				err := os.Mkdir("./certs/node"+strconv.Itoa(i), 0644)
				if err != nil {
					log.Panic()
				}
			}
			pri, pub := GetKeyPair()
			priFilePath := "./certs/node" + strconv.Itoa(i) + "/rsa.pri.pem"
			file, err := os.OpenFile(priFilePath, os.O_RDWR|os.O_CREATE, 0644)
			if err != nil {
				log.Panic(err)
			}
			defer file.Close()
			file.Write(pri)

			pubFilePath := "./certs/node" + strconv.Itoa(i) + "/rsa.pub.pem"
			file2, err := os.OpenFile(pubFilePath, os.O_RDWR|os.O_CREATE, 0644)
			if err != nil {
				log.Panic(err)
			}
			defer file2.Close()
			file2.Write(pub)
		}
		fmt.Println("已为节点们生成RSA公私钥")
	}
}

//生成rsa公私钥
func GetKeyPair() (prvkey, pubkey []byte) {
	// 生成私钥文件
	privateKey, err := rsa.GenerateKey(rand.Reader, 1024)
	if err != nil {
		panic(err)
	}
	derStream := x509.MarshalPKCS1PrivateKey(privateKey)
	block := &pem.Block{
		Type:  "RSA PRIVATE KEY",
		Bytes: derStream,
	}
	prvkey = pem.EncodeToMemory(block)
	publicKey := &privateKey.PublicKey
	derPkix, err := x509.MarshalPKIXPublicKey(publicKey)
	if err != nil {
		panic(err)
	}
	block = &pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: derPkix,
	}
	pubkey = pem.EncodeToMemory(block)
	return
}

//判断文件或文件夹是否存在
func IsExist(path string) bool {
	_, err := os.Stat(path)
	if err != nil {
		if os.IsExist(err) {
			return true
		}
		if os.IsNotExist(err) {
			return false
		}
		fmt.Println(err)
		return false
	}
	return true
}

func ReadKeyPair(keyDir string) ([]byte, []byte) {
	fmt.Println("read key pair from", keyDir)
	priKey, err := ioutil.ReadFile(keyDir + "/rsa.pri.pem")
	if err != nil {
		log.Panic(err)
	}
	pubKey, err := ioutil.ReadFile(keyDir + "/rsa.pub.pem")
	if err != nil {
		log.Panic(err)
	}
	return priKey, pubKey
}

//数字签名
func RsaSignWithSha256(data []byte, keyBytes []byte) []byte {
	h := sha256.New()
	h.Write(data)
	hashed := h.Sum(nil)
	block, _ := pem.Decode(keyBytes)
	if block == nil {
		panic(errors.New("private key error"))
	}
	privateKey, err := x509.ParsePKCS1PrivateKey(block.Bytes)
	if err != nil {
		fmt.Println("ParsePKCS8PrivateKey err", err)
		panic(err)
	}

	signature, err := rsa.SignPKCS1v15(rand.Reader, privateKey, crypto.SHA256, hashed)
	if err != nil {
		fmt.Printf("Error from signing: %s\n", err)
		panic(err)
	}

	return signature
}

//签名验证
func RsaVerifyWithSha256(data, sign, keyBytes []byte) bool {
	block, _ := pem.Decode(keyBytes)
	if block == nil {
		panic(errors.New("public key error"))
	}
	pubKey, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		panic(err)
	}

	hashed := sha256.Sum256(data)
	err = rsa.VerifyPKCS1v15(pubKey.(*rsa.PublicKey), crypto.SHA256, hashed[:], sign)
	if err != nil {
		panic(err)
	}
	return true
}

func Sha256Digest(msg interface{}) []byte {
	msgBytes := JsonMarshal(msg)

	sha256 := sha256.New()
	sha256.Write(msgBytes)

	return sha256.Sum(nil)
}

func JsonMarshal(msg interface{}) []byte {
	msgBytes, err := json.Marshal(msg)
	if err != nil {
		log.Panic(err)
	}
	return msgBytes
}

func VerifySignMsg(signMsg *SignMessage, pubKey []byte) bool {
	if signMsg.Msg.MsgType == MtPrePrepare {
		return VerifyPrePreSignMsg(signMsg, pubKey)
	}
	digest := Sha256Digest(signMsg.Msg)
	result := RsaVerifyWithSha256(digest, signMsg.Sign, pubKey)

	return result
}

func VerifyPrePreSignMsg(signMsg *SignMessage, pubKey []byte) bool {
	txs := signMsg.Msg.Req.Txs
	signs := signMsg.TxSigns
	if txs == nil || signs == nil || len(txs) != len(signs) {
		return false
	}
	digestTime, verifyTime := time.Duration(0), time.Duration(0)
	for idx, tx := range txs {
		sign := signs[idx]
		start := time.Now()
		digest := Sha256Digest(tx)
		digestTime += time.Since(start)
		start = time.Now()
		if !RsaVerifyWithSha256(digest, sign, pubKey) {
			return false
		}
		verifyTime += time.Since(start)
	}
	fmt.Println("digestTime:", digestTime)
	fmt.Println("verifyTime:", verifyTime)
	return true
}

func GetSignMsg(msg *Message, priKey []byte) *SignMessage {
	if msg.MsgType == MtPrePrepare {
		return GetPrePreSignMsg(msg, priKey)
	}
	digest := Sha256Digest(msg)
	sign := RsaSignWithSha256(digest, priKey)
	return &SignMessage{msg, sign, nil}
}

func GetPrePreSignMsg(msg *Message, priKey []byte) *SignMessage {
	signMsg := &SignMessage{Msg: msg}
	if signMsg.Msg.Req.Txs == nil {
		return signMsg
	}
	digestTime, signTime := time.Duration(0), time.Duration(0)
	signMsg.TxSigns = make([][]byte, 0)
	for _, tx := range msg.Req.Txs {
		start := time.Now()
		digest := Sha256Digest(tx)
		digestTime += time.Since(start)
		start = time.Now()
		sign := RsaSignWithSha256(digest, priKey)
		signTime += time.Since(start)
		signMsg.TxSigns = append(signMsg.TxSigns, sign)
	}
	fmt.Println("digestTime:", digestTime)
	fmt.Println("signTime:", signTime)
	return signMsg
}
