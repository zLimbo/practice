package pbft

import (
	"fmt"
	"log"
	"time"
)

type Batch struct {
	time1, time2, time3    int64
	count1, count2, count3 int
}

type PbftStat struct {
	requestNum, prePrepareNum, prepareNum, commitNum, replyNum int64
	prePrepareTime, prepareTime, commitTime                    int64
	batchTimeOkNum                                             int64
	time1, time2, time3, time4                                 int64
	time3pcSum, time2pcSum                                     int64
	count3pc, count2pc                                         int64
	postErrNum                                                 int
	times                                                      []int64
}

type Pbft struct {
	node        *Node
	stat        *PbftStat
	msgCertPool map[int64]*MsgCert
	recvChan    chan *SignMessage
	sendChan    chan *SendTask
	boostChan   chan int64
	batchPool   map[int64]*Batch
	batchSeq    int64
	curBatch    *Batch
}

func NewPbft(id int64) *Pbft {
	pbft := &Pbft{
		node:        GetNode(id),
		stat:        &PbftStat{times: make([]int64, 0)},
		msgCertPool: make(map[int64]*MsgCert),
		recvChan:    make(chan *SignMessage, ChanSize),
		sendChan:    make(chan *SendTask, ChanSize),
		boostChan:   make(chan int64, ChanSize),
		batchPool:   make(map[int64]*Batch),
		batchSeq:    0,
		curBatch:    &Batch{},
	}
	pbft.batchPool[pbft.batchSeq] = pbft.curBatch
	return pbft
}

func (pbft *Pbft) Start() {
	go pbft.recvMsg()
	go pbft.sendMsg()
	pbft.listen()
}

func (pbft *Pbft) getMsgCert(seq int64) *MsgCert {
	msgCert, ok := pbft.msgCertPool[seq]
	if !ok {
		msgCert = NewMsgCert()
		pbft.msgCertPool[seq] = msgCert
		msgCert.Seq = seq
	}
	return msgCert
}

func (pbft *Pbft) handleRequest(msg *Message) {
	log.Println("<node handleRequestMsg> msg seq=", msg.Seq, "tx num", len(msg.Txs))
	msgCert := pbft.getMsgCert(msg.Seq)
	if msgCert.Req != nil {
		log.Printf("The request(seq=%d) has been accepted!\n", msg.Seq)
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.Req = msg
	msgCert.SendPrePrepare = WaitSend

	msgCert.Time = time.Now().UnixNano()
	msgCert.PrePrepareTime = time.Now().UnixNano()
	pbft.curBatch.time1 = time.Now().UnixNano()
	LogStageStart(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))

	pbft.sendPrePrepare(msgCert)
}

func (pbft *Pbft) handlePrePrepare(msg *Message) {
	log.Println("<node handlePrePrepareMsg> msg seq=", msg.Seq, "tx num", len(msg.Txs))
	msgCert := pbft.getMsgCert(msg.Seq)
	if msgCert.PrePrepare != nil {
		log.Printf("The pre-prepare(seq=%d) has been accepted!\n", msg.Seq)
		return
	}
	if msgCert.SendPrepare == HasSend {
		return
	}

	msgCert.Seq = msg.Seq
	msgCert.PrePrepare = msg
	msgCert.SendPrepare = WaitSend

	msgCert.Time = time.Now().UnixNano()
	msgCert.PrepareTime = time.Now().UnixNano()
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))

	pbft.sendPrepare(msgCert)
}

func (pbft *Pbft) handlePrepare(msg *Message) {
	msgCert := pbft.getMsgCert(msg.Seq)
	if msgCert.SendCommit == HasSend {
		return
	}
	log.Printf("<node handlePrepareMsg> msg seq=%d nodeId=%d\n", msg.Seq, msg.NodeId)
	pbft.recvPrepareMsg(msgCert, msg)
	pbft.maybeSendCommit(msgCert)
}

func (pbft *Pbft) handleCommit(msg *Message) {
	msgCert := pbft.getMsgCert(msg.Seq)
	if msgCert.SendReply == HasSend {
		return
	}
	log.Printf("<node handleCommitMsg> msg seq=%d nodeId=%d\n", msg.Seq, msg.NodeId)
	pbft.recvCommitMsg(msgCert, msg)
	pbft.maybeSendReply(msgCert)
}

func (pbft *Pbft) recvPrepareMsg(msgCert *MsgCert, msg *Message) {
	// count := 1
	// for _, preMsg := range msgCert.Prepares {
	// 	if preMsg.NodeId == msg.NodeId {
	// 		return
	// 	}
	// 	if preMsg.Digest == msg.Digest {
	// 		count++
	// 	}
	// }
	msgCert.Prepares = append(msgCert.Prepares, msg)
	count := len(msgCert.Prepares)
	log.Printf("same prepare msg count=%d\n", count)
	if count >= 2*f {
		msgCert.SendCommit = WaitSend
	}
}

func (pbft *Pbft) recvCommitMsg(msgCert *MsgCert, msg *Message) {
	// count := 1
	// for _, preMsg := range msgCert.Commits {
	// 	if preMsg.NodeId == msg.NodeId {
	// 		return
	// 	}
	// 	if preMsg.Digest == msg.Digest {
	// 		count++
	// 	}
	// }
	msgCert.Commits = append(msgCert.Commits, msg)
	count := len(msgCert.Commits)
	log.Printf("same commit msg count=%d\n", count)
	if count >= 2*f+1 {
		msgCert.SendReply = WaitSend
	}
}

func (pbft *Pbft) sendPrePrepare(msgCert *MsgCert) {
	prePrepareMsg := &Message{
		MsgType:   MtPrePrepare,
		Seq:       msgCert.Seq,
		NodeId:    pbft.node.id,
		Timestamp: time.Now().UnixNano(),
		Req:       msgCert.Req,
	}
	signMsg := GetSignMsg(prePrepareMsg, pbft.node.priKey)
	pbft.broadcast(signMsg, msgCert)
	msgCert.SendPrePrepare = HasSend
	log.Println("[pre-prepare] msg has been sent.")

	msgCert.PrePrepareTime = time.Now().UnixNano() - msgCert.PrePrepareTime
	LogStageEnd(fmt.Sprintf("seq=%d pre-prepare", msgCert.Seq))

	msgCert.PrepareTime = time.Now().UnixNano()
	msgCert.SendPrepare = HasSend
	LogStageStart(fmt.Sprintf("seq=%d prepare", msgCert.Seq))
	pbft.maybeSendCommit(msgCert)
}

func (pbft *Pbft) sendPrepare(msgCert *MsgCert) {
	prepareMsg := &Message{
		MsgType:   MtPrepare,
		Seq:       msgCert.Seq,
		NodeId:    pbft.node.id,
		Timestamp: time.Now().UnixNano(),
	}
	pbft.recvPrepareMsg(msgCert, prepareMsg)
	signMsg := GetSignMsg(prepareMsg, pbft.node.priKey)
	log.Println("<broadcast> prepare")
	pbft.broadcast(signMsg, msgCert)
	msgCert.SendPrepare = HasSend
	pbft.stat.prePrepareNum++
	pbft.curBatch.count1++

	if pbft.curBatch.count1 == BoostNum-1 {
		pbft.curBatch.time1 = time.Now().UnixNano() - pbft.curBatch.time1
		pbft.curBatch.time2 = time.Now().UnixNano()
		fmt.Println("Cal time1:", pbft.curBatch.time1)
	}
	log.Println("[prepare] msg has been sent.")
	pbft.maybeSendCommit(msgCert)
}

func (pbft *Pbft) maybeSendCommit(msgCert *MsgCert) {
	if msgCert.SendPrepare != HasSend || msgCert.SendCommit != WaitSend {
		return
	}
	pbft.stat.prepareNum++

	msgCert.PrepareTime = time.Now().UnixNano() - msgCert.PrepareTime
	LogStageEnd(fmt.Sprintf("seq=%d prepare", msgCert.Seq))

	pbft.curBatch.count2++
	if pbft.curBatch.count2 == BoostNum {
		pbft.curBatch.time2 = time.Now().UnixNano() - pbft.curBatch.time2
		pbft.curBatch.time3 = time.Now().UnixNano()
		fmt.Println("Cal time2:", pbft.curBatch.time2)
	}

	msgCert.CommitTime = time.Now().UnixNano()
	LogStageStart(fmt.Sprintf("seq=%d commit", msgCert.Seq))

	commitMsg := &Message{
		MsgType:   MtCommit,
		Seq:       msgCert.Seq,
		NodeId:    pbft.node.id,
		Timestamp: time.Now().UnixNano(),
	}

	pbft.recvCommitMsg(msgCert, commitMsg)
	signMsg := GetSignMsg(commitMsg, pbft.node.priKey)
	pbft.broadcast(signMsg, msgCert)
	msgCert.SendCommit = HasSend
	log.Println("[commit] msg has been sent.")
	pbft.maybeSendReply(msgCert)
}

func (pbft *Pbft) maybeSendReply(msgCert *MsgCert) {
	if msgCert.SendCommit != HasSend || msgCert.SendReply != WaitSend {
		return
	}

	msgCert.Time = time.Now().UnixNano() - msgCert.Time
	msgCert.CommitTime = time.Now().UnixNano() - msgCert.CommitTime
	pbft.stat.commitNum++
	LogStageEnd(fmt.Sprintf("seq=%d commit", msgCert.Seq))

	LogStageStart(fmt.Sprintf("seq=%d reply", msgCert.Seq))
	replyMsg := &Message{
		MsgType:   MtReply,
		Seq:       msgCert.Seq,
		NodeId:    pbft.node.id,
		Timestamp: time.Now().UnixNano(),
	}
	signMsg := GetSignMsg(replyMsg, pbft.node.priKey)
	pbft.sendChan <- &SendTask{
		addr:    ClientAddr,
		msg:     signMsg,
		msgCert: msgCert,
	}
	// go PostJson(ClientUrl+"/getReply", jsonMsg)
	msgCert.SendReply = HasSend

	log.Printf("[reply] msg has been sent, seq=%d\n", msgCert.Seq)
	LogStageEnd(fmt.Sprintf("seq=%d reply reply_count=%d", msgCert.Seq, pbft.stat.replyNum))
	pbft.stat.replyNum++

	pbft.finalize(msgCert)
}

func (pbft *Pbft) finalize(msgCert *MsgCert) {
	// pbft.showTime(msgCert)

	pbft.curBatch.count3++
	if pbft.curBatch.count3 == BoostNum {
		pbft.curBatch.time3 = time.Now().UnixNano() - pbft.curBatch.time3
		fmt.Println("Cal time3:", pbft.curBatch.time3)

		LogStageEnd(fmt.Sprintf("Batch %d", pbft.batchSeq))
		pbft.showBatchTime()
		pbft.exec(msgCert)
		pbft.curBatch = &Batch{}
		pbft.batchSeq += 1
		pbft.batchPool[pbft.batchSeq] = pbft.curBatch
		pbft.boostChan <- pbft.batchSeq

		LogStageStart(fmt.Sprintf("Batch %d", pbft.batchSeq))
	}

	pbft.clearCert(msgCert)
}

func (pbft *Pbft) exec(msgCert *MsgCert) {
	LogStageStart("Exec")
	start := time.Now()
	sum := int64(0)
	for i := int64(0); i <= ExecNum; i++ {
		sum += i
	}
	fmt.Println("Exec result:", sum)
	LogStageEnd("Exec")
	fmt.Println("Exec time:", time.Since(start))
}

func (pbft *Pbft) clearCert(msgCert *MsgCert) {
	msgCert.Req = nil
	msgCert.PrePrepare = nil
	msgCert.Prepares = nil
	msgCert.Commits = nil
}
