package pbft

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"runtime"
	"time"
)

var SendTaskChan chan int

func init() {
	SendTaskChan = make(chan int, sendTaskSize)
	for i := 1; i <= sendTaskSize; i++ {
		SendTaskChan <- i
	}
}

type SendTask struct {
	msg     *SignMessage
	addr    string
	msgCert *MsgCert
}

func (pbft *Pbft) listen() {
	listen, err := net.Listen("tcp", pbft.node.addr)
	if err != nil {
		log.Panic(err)
	}
	defer listen.Close()
	fmt.Println(pbft.node.addr, "server listen...")
	for {
		conn, err := listen.Accept()
		if err != nil {
			fmt.Println(err)
			continue
		}
		msgBytes, err := ioutil.ReadAll(conn)
		conn.Close()
		if err != nil {
			fmt.Println(err)
			continue
		}
		msg := new(SignMessage)
		if err := json.Unmarshal(msgBytes, msg); err != nil {
			fmt.Println(err)
			continue
		}
		pbft.recvChan <- msg
	}
}

func (pbft *Pbft) recvMsg() {
	for signMsg := range pbft.recvChan {
		node := GetNode(signMsg.Msg.NodeId)
		if !VerifySignMsg(signMsg, node.pubKey) {
			fmt.Println("#### verify failed!")
			continue
		}
		msg := signMsg.Msg
		fmt.Println("+ handle start + batch seq:", pbft.batchSeq)
		fmt.Println("recv msg{", msg.MsgType, msg.Seq, msg.NodeId, msg.Timestamp, "}")
		switch msg.MsgType {
		case MtRequest:
			pbft.handleRequest(msg)
		case MtPrePrepare:
			pbft.handlePrePrepare(msg)
		case MtPrepare:
			pbft.handlePrepare(msg)
		case MtCommit:
			pbft.handleCommit(msg)
		}

		fmt.Printf("[req=%d, pre-prepare=%d, prepare=%d, commit=%d, reply=%d]\n",
			pbft.stat.requestNum,
			pbft.stat.prePrepareNum,
			pbft.stat.prepareNum,
			pbft.stat.commitNum,
			pbft.stat.replyNum)
		fmt.Println("post err num:", pbft.stat.postErrNum)
		fmt.Println("goroutine num:", runtime.NumGoroutine())

		fmt.Println("+ handle end + batch seq:", pbft.batchSeq)
	}
}

func (pbft *Pbft) sendMsg() {
	for sendTask := range pbft.sendChan {
		sendTaskNo := <-SendTaskChan
		go pbft.tcpDial(sendTask, sendTaskNo)
	}
}

func (pbft *Pbft) tcpDial(sendTask *SendTask, sendTaskNo int) {
	var conn net.Conn
	var err error

	if conn, err = net.Dial("tcp", sendTask.addr); err == nil {
		var msgBytes []byte
		if msgBytes, err = json.Marshal(sendTask.msg); err == nil {
			if _, err = conn.Write(msgBytes); err == nil {
				conn.Close()
				SendTaskChan <- sendTaskNo
				return
			}
		}
		conn.Close()
	}
	SendTaskChan <- sendTaskNo
	fmt.Println("send error:", err)
	pbft.stat.postErrNum++
	pbft.sendChan <- sendTask
}

func (pbft *Pbft) broadcast(signMsg *SignMessage, msgCert *MsgCert) {

	for _, node := range NodeTable {
		if node.id == pbft.node.id {
			continue
		}
		// fmt.Println("send to: " + url + path)
		pbft.sendChan <- &SendTask{
			addr:    node.addr,
			msg:     signMsg,
			msgCert: msgCert,
		}
	}
}

func (pbft *Pbft) BoostReq(reqNum, boostDelay int) {

	req := &Message{
		MsgType:   MtRequest,
		Seq:       1,
		NodeId:    1,
		Timestamp: time.Now().UnixNano(),
		Txs:       &BatchTx{},
	}

	jsonMsg, err := json.Marshal(req)
	if err != nil {
		fmt.Println(err)
	}

	fmt.Println("# boost num =", reqNum, ", sz =", float64(len(jsonMsg))/MbSize)
	fmt.Println("# boostSeqChan len:", len(pbft.boostChan))
	time.Sleep(time.Duration(boostDelay) * time.Millisecond)

	pbft.boostChan <- 0

	LogStageStart(fmt.Sprintf("Batch %d", pbft.batchSeq))
	prefix := pbft.node.id * 10000
	for batchSeq := range pbft.boostChan {
		if batchSeq == int64(reqNum) {
			break
		}
		fmt.Println("# batchSeq:", batchSeq)
		reqMsg := &Message{
			MsgType:   MtRequest,
			Seq:       prefix + batchSeq,
			NodeId:    pbft.node.id,
			Timestamp: time.Now().UnixNano(),
			Txs:       new(BatchTx),
		}
		signMsg := GetSignMsg(reqMsg, pbft.node.priKey)
		// pbft.RecvChan.RequestMsgChan <- reqMsg
		pbft.recvChan <- signMsg
	}
}
