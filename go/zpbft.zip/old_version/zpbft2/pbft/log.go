package pbft

import (
	"fmt"
	"math"
	"time"
)

func LogStageStart(msg string) {
	fmt.Printf("\033[031m[%s START] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}

func LogStageEnd(msg string) {
	fmt.Printf("\033[032m[%s END] timestamp:%d\033[0m\n", msg, time.Now().Unix())
}

func ToSecond(timestamp int64) float64 {
	return float64(timestamp) / math.Pow10(9)
}

func (pbft *Pbft) showBatchTime() {
	fmt.Printf("\033[34m\n[Batch Time seq=%d]\033[0m\n", pbft.batchSeq)

	fmt.Printf("count1: %d, count2: %d, count3: %d\n", pbft.curBatch.count1, pbft.curBatch.count2, pbft.curBatch.count3)
	fmt.Println("[sum]")
	fmt.Printf("time1: %0.6fs\n", ToSecond(pbft.curBatch.time1))
	fmt.Printf("time2: %0.6fs\n", ToSecond(pbft.curBatch.time2))
	fmt.Printf("time3: %0.6fs\n", ToSecond(pbft.curBatch.time3))
	stat := pbft.stat
	if ToSecond(pbft.curBatch.time1) < 10 &&
		ToSecond(pbft.curBatch.time2) < 10 &&
		ToSecond(pbft.curBatch.time3) < 10 {
		stat.time1 += pbft.curBatch.time1
		stat.time2 += pbft.curBatch.time2
		stat.time3 += pbft.curBatch.time3
		stat.batchTimeOkNum++
	}
	if stat.batchTimeOkNum > 0 {
		fmt.Println("\n[avg] batch num:", len(pbft.batchPool), "pbft.batchTimeOkNum:", stat.batchTimeOkNum)
		fmt.Printf("time1: %0.6f\n", ToSecond(stat.time1/int64(stat.batchTimeOkNum)))
		fmt.Printf("time2: %0.6f\n", ToSecond(stat.time2/int64(stat.batchTimeOkNum)))
		fmt.Printf("time3: %0.6f\n", ToSecond(stat.time3/int64(stat.batchTimeOkNum)))
	}

	fmt.Println()
}

func (pbft *Pbft) showTime(msgCert *MsgCert) {
	fmt.Printf("\033[34m\n[MsgCert Time seq=%d]\033[0m\n", msgCert.Seq)
	// fmt.Printf("request:\t%0.6fs\n", float64(msgCert.RequestTime)/math.Pow10(9))
	// fmt.Printf("pre-prepare:\t%0.6fs\n", float64(msgCert.PrePrepareTime)/math.Pow10(9))
	// fmt.Printf("prepare:\t%0.6fs\n", float64(msgCert.PrepareTime)/math.Pow10(9))
	// fmt.Printf("commit:\t\t%0.6fs\n", float64(msgCert.CommitTime)/math.Pow10(9))
	// fmt.Printf("cert time:\t%0.6fs\n", float64(msgCert.Time)/math.Pow10(9))
	// fmt.Printf("cert time2:\t%0.6fs\n", float64(msgCert.Time2)/math.Pow10(9))
	stat := pbft.stat
	fmt.Println("\nnode times:")
	for idx, time := range stat.times {
		fmt.Printf("%d: %0.6fs\n", idx, float64(time)/math.Pow10(9))
	}
	fmt.Println()

	fmt.Println("")
	if msgCert.Seq/10000 == pbft.node.id {
		stat.time3pcSum += msgCert.Time
		stat.count3pc++
	} else {
		stat.time2pcSum += msgCert.Time
		stat.count2pc++
		stat.prepareTime += msgCert.PrepareTime
		stat.commitTime += msgCert.CommitTime
	}

	fmt.Printf("\033[34m\n[Avg Time]\033[0m\n")
	fmt.Println("node time info:")
	fmt.Println("count3pc:", stat.count3pc, "count2pc:", stat.count2pc)
	fmt.Printf("stat.time3pcSum:\t%0.6fs\n", float64(stat.time3pcSum)/math.Pow10(9))
	fmt.Printf("stat.time2pcSum:\t%0.6fs\n", float64(stat.time2pcSum)/math.Pow10(9))
	fmt.Printf("stat.prepareTime:\t%0.6fs\n", float64(stat.prepareTime)/math.Pow10(9))
	fmt.Printf("stat.commitTime:\t%0.6fs\n", float64(stat.commitTime)/math.Pow10(9))
	fmt.Printf("stat.prepareTime + stat.commitTime:\t%0.6fs\n", float64(stat.prepareTime+stat.commitTime)/math.Pow10(9))

	fmt.Println("Avg time info:")
	if stat.count3pc == 0 || stat.count2pc == 0 {
		return
	}
	avgTime3pc := float64(stat.time3pcSum) / float64(stat.count3pc)
	avgTime2pc := float64(stat.time2pcSum) / float64(stat.count2pc)
	avgTimePrePrepare := avgTime3pc - avgTime2pc
	avgTimePrepare := float64(stat.prepareTime) / float64(stat.count2pc)
	avgTimeCommit := float64(stat.commitTime) / float64(stat.count2pc)

	fmt.Printf("avgTime3pc:\t%0.6fs\n", avgTime3pc/math.Pow10(9))
	fmt.Printf("avgTime2pc:\t%0.6fs\n", avgTime2pc/math.Pow10(9))
	fmt.Printf("avgTimePrePrepare:\t%0.6fs\n", avgTimePrePrepare/math.Pow10(9))
	fmt.Printf("avgTimePrepare:\t%0.6fs\n", avgTimePrepare/math.Pow10(9))
	fmt.Printf("avgTimeCommit:\t%0.6fs\n", avgTimeCommit/math.Pow10(9))

}
