package pbft

const (
	delayTime   = 30 * 100000
	batchNum    = 4
	clientDelay = 3
	ClientAddr  = "10.11.6.119:8000"
	// ClientUrl = "localhost:8800"

	from       = 101
	to         = 102
	MbSize     = 1024 * 1024
	BatchTxNum = 4096
	TxSize     = 256

	ChanSize     = 10000
	sendTaskSize = 256

	ExecTime = 0
	ExecNum  = 1e10
)

var (
	f          int
	BoostNum   int
	BoostDelay int = 5
	NodeNum    int
)
