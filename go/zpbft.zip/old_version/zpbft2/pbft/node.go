package pbft

import (
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"strconv"
	"strings"
)

type Node struct {
	id     int64
	addr   string
	priKey []byte
	pubKey []byte
}

var (
	NodeTable map[int64]*Node
	Ips       []string
	Ids       []int64
)

func InitNodeAddr(ipNum, processNum int) error {

	Ips = GetIps()
	fmt.Println("# Ips:", Ips)

	NodeTable = make(map[int64]*Node)

	for _, ip := range Ips[:ipNum] {
		idPrefix := Ip2I64(ip)
		for i := 1; i <= processNum; i++ {
			id := idPrefix*int64(100) + int64(i)
			addr := ip + ":" + strconv.Itoa(8000+i)
			keyDir := "./certs/" + fmt.Sprint(id)
			priKey, pubKey := ReadKeyPair(keyDir)
			node := &Node{id, addr, priKey, pubKey}
			NodeTable[id] = node
			Ids = append(Ids, id)
		}
	}

	f = (len(NodeTable) - 1) / 3
	NodeNum = len(NodeTable)

	fmt.Println("# network server peers:")
	for _, node := range NodeTable {
		fmt.Printf("# node id: %d, node addr: %s\n", node.id, node.addr)
	}
	fmt.Println("# client:", ClientAddr)
	fmt.Printf("\n# node num: %d\tf: %d\n", len(NodeTable), f)

	fmt.Println()

	return nil
}

func GetOutBoundIP() string {
	ipBytes, err := ioutil.ReadFile("local_ip.txt")
	if err == nil {
		ip := string(ipBytes)
		fmt.Println("** get ip from local_ip.txt, ip:", ip)
		return ip
	}

	conn, err := net.Dial("udp", "8.8.8.8:53")
	if err != nil {
		log.Panic(err)
	}
	localAddr := conn.LocalAddr().(*net.UDPAddr)
	log.Println("localAddr:", localAddr.String())
	ip := strings.Split(localAddr.String(), ":")[0]
	fmt.Println("** get ip from dial, ip:", ip)

	if err = ioutil.WriteFile("local_ip.txt", []byte(ip), 0644); err != nil {
		log.Panic(err)
	}
	return ip
}

func GetIps() []string {

	data, err := ioutil.ReadFile("ips.txt")
	if err != nil {
		log.Panic(err)
	}

	ips := strings.Split(string(data), "\n")
	if len(ips) == 1 {
		log.Panic("read Ips error!")
	}
	return ips
}

func Ip2I64(ip string) int64 {
	res := int64(0)

	for _, span := range strings.Split(ip, ".") {
		num, err := strconv.Atoi(span)
		if err != nil {
			log.Panic(err)
			return 0
		}
		res = res*1000 + int64(num)
	}
	return res
}

func GetNode(id int64) *Node {
	if NodeTable == nil {
		log.Panic("NodeTable is not initialized!")
	}
	node, ok := NodeTable[id]
	if !ok {
		log.Panicf("The node of this ID(%d) does not exist!", id)
	}
	return node
}
