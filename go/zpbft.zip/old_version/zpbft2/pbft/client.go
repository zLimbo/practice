package pbft

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math"
	"net"
	"time"
)

type Client struct {
	addr          string
	recvChan      chan *SignMessage
	replyCertPool map[int64]*ReplyCert
	applyNum      int
	startTime     int64
}

func NewClient(addr string) *Client {
	client := &Client{
		addr:          addr,
		recvChan:      make(chan *SignMessage, ChanSize),
		replyCertPool: make(map[int64]*ReplyCert),
	}
	return client
}

func (client *Client) Start() {
	client.startTime = time.Now().UnixNano() + int64(clientDelay*math.Pow10(9))
	go client.handleReply()
	client.listen()
}

func (client *Client) listen() {
	listen, err := net.Listen("tcp", client.addr)
	if err != nil {
		log.Panic(err)
	}
	defer listen.Close()

	fmt.Println(client.addr, "client listen...")
	acceptNum := 0
	for {
		conn, err := listen.Accept()
		acceptNum++
		// fmt.Println("## acceptNum:", acceptNum, " recv chan size:", len(client.recvChan))
		if err != nil {
			fmt.Println(err)
			continue
		}
		msgBytes, err := ioutil.ReadAll(conn)

		if err != nil {
			fmt.Println(err)
			continue
		}
		msg := new(SignMessage)
		if err := json.Unmarshal(msgBytes, msg); err != nil {
			fmt.Println(err)
			continue
		}
		client.recvChan <- msg
		conn.Close()
	}
}

func (client *Client) getReplyCert(seq int64) *ReplyCert {
	cert, ok := client.replyCertPool[seq]
	if !ok {
		cert = NewReplyCert(seq)
		client.replyCertPool[seq] = cert
	}
	return cert
}

func (client *Client) handleReply() {
	for signMsg := range client.recvChan {
		// fmt.Println("handle reply:", msg)
		node := GetNode(signMsg.Msg.NodeId)
		if !VerifySignMsg(signMsg, node.pubKey) {
			fmt.Println("#### verify failed!")
			continue
		}
		msg := signMsg.Msg
		if msg.MsgType != MtReply {
			fmt.Println("it's not reply!")
			continue
		}
		cert := client.getReplyCert(msg.Seq)
		if cert.CanApply {
			continue
		}
		count := 1
		for _, preMsg := range cert.Replys {
			if preMsg.NodeId == msg.NodeId {
				return
			}
			count++
			// if preMsg.Digest == msg.Digest {
			// 	count++
			// }
		}
		cert.Replys = append(cert.Replys, msg)
		fmt.Printf("\033[32m[Reply]\033[0m msg seq=%d node_id=%d, count=%d\n", msg.Seq, msg.NodeId, count)
		if count < f+1 {
			continue
		}
		cert.CanApply = true
		client.applyNum++
		fmt.Printf("[time] apply num=%d\tspend time=%0.6f\n", client.applyNum, ToSecond(time.Now().UnixNano()-client.startTime))
	}
}
