import os
import sys
from multiprocessing import Process

def run(num, boost_num, sz):
    process_list = []
    for i in range(1, num + 1):
        log_file = 'log/log_{}_{}.txt'.format(num, i)
        cmd = 'go run main.go {} {} {} {} > {} 2>&1'.format(i, num, boost_num, sz, log_file)
        print(">>>", cmd)
        p = Process(target=os.system, args=(cmd,))
        p.start()
        process_list.append(p)
    
if __name__ == '__main__':
    num = int(sys.argv[1])
    boost_num = 0
    if len(sys.argv) > 2:
        boost_num = int(sys.argv[2])
    sz = 0
    if len(sys.argv) > 3:
        sz = int(sys.argv[3])
    run(num, boost_num, sz)