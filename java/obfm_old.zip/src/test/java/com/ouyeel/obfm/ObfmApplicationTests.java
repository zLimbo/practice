package com.ouyeel.obfm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObfmApplicationTests {

    @Test
    void contextLoads() {
    }

}
