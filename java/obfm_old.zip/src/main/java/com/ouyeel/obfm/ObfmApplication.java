package com.ouyeel.obfm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObfmApplication {

    public static void main(String[] args) {
        SpringApplication.run(ObfmApplication.class, args);
    }

}
